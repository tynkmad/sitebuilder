<script setup lang="ts">
</script>

<template>
  <main class="landing-page">
    Templates
  </main>
</template>
<style scoped>

</style>