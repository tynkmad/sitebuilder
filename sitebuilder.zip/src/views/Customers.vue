<script setup lang="ts">
</script>

<template>
  <main class="landing-page">
    Customers
  </main>
</template>
<style scoped>

</style>