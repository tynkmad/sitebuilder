<script setup lang="ts">
</script>

<template>
  <main class="landing-page">
    Integrations
  </main>
</template>
<style scoped>

</style>