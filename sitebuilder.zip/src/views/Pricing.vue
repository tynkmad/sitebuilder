<script setup lang="ts">
</script>

<template>
  <main class="landing-page">
    Pricing
  </main>
</template>
<style scoped>

</style>