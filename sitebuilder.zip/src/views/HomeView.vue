<script setup lang="ts">
</script>

<template>
  <main class="landing-page">
    Landing Page
  </main>
</template>
<style scoped>

</style>