<script setup lang="ts">
</script>
<template>
    <!-- #region About -->
    <section id="dvaMenuabout" class="about-us">
        <div class="sk-container">
            <div class="sk-row">
                <div class="sk-col-4 sk-col-fluid">
                    <h2>
                        About Elder Care
                        <div class="sk-body-text-2">in adyar</div>
                    </h2>
                </div>
                <div class="sk-col-8 sk-col-fluid">
                    <p class="sk-margin-bottom-0">
                        Elder Care is a haven of warmth and support, dedicated to
                        enhancing the quality of life for the elderly. Situated in the
                        peaceful surroundings of adyar, we are committed to providing a
                        compassionate and caring environment where seniors can enjoy
                        their golden years. Our home is staffed by a team of experienced
                        and empathetic professionals who prioritize the health, safety,
                        and well-being of our residents. We offer a range of specialized
                        services, including personalized medical care, nutritious meals,
                        engaging recreational activities, and 24/7 assistance. At Elder
                        Care, we strive to create a community where every resident feels
                        respected, valued, and cared for as part of our extended family.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- #endregion About -->
</template>
<style  >
/* About us :: BEGIN */
.about-us {
    text-align: left;

    p {
        line-height: var(--line-height-large);
    }

    .sk-body-text-2 {
        font-size: 1.6rem;
        margin-top: 0.5rem;
    }
}

/* About us :: END */
</style>