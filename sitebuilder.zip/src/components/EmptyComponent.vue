<script setup>
import SkEmptyState from 'rolex/skemptystate.vue'
</script>
<template>
    <SkEmptyState :showEmptyState="true" content="Click on the components on the left to add one by one."
        contentTitle="Select a component to start"
        emptyStateImage="https://lscdn.blob.core.windows.net/content/pro-manage/sme/web-profile-images/web-designing-empty-state.svg" />
</template>