<script lang="ts">
export default {
  name: "SkAppbar",
};
</script>

<script setup lang="ts">
import { skActionItem } from "./skglobaltypes";
import SkIcon from "./skicon.vue";
import SkButton from "./skbutton.vue";
import { computed, ref, watch, onMounted } from "vue";
import SkBadge from "./skbadge.vue";
import { useOnClickOutside } from "./onClickOutside";
import { devConsoleLog } from "./utilFunctions";
// define all the customizable properties
interface Props {
  appBarLeftIconStyle: string; // what icon should be placed on the left aligned Navigation area options are - arrow_back, ham_menu, close.  empty will hide nav
  appBarTitle: string; // to display as part of the appnav left aligned
  appBarActionItems?: skActionItem[]; //  list of menu items on the right.  first 2 should be shown as icons rest inside a tripple dot menu
  skNoShadow?: boolean; // Not used anywhere, check and remove
  skround?: boolean; // Not used anywhere, check and remove
  buttongroup?: string; // Not used anywhere, check and remove
  overflowWhen?: number;
  isMobileHide?: boolean;
  useSvg?: boolean; // if we need to use SVG icons in appbar send useSvg=true , it will show svg icons
  containerFixed?: boolean; // Activate the fixed-width box modal container within the app bar.
  showLeftActionWeb?: boolean; // The left action of the app bar is hidden on the web by default. However, by using this property, you can make the left side action visible on the web.
  appBarBoxShadow?: boolean; // Add a box shadow to the app bar. It doesn't have a shadow by default.
  sticky?: boolean;
  appBarSubTitle?: string;
}

const props = defineProps<Props>();

const emit = defineEmits([
  "actionItemClick",
  "overFlowMenuItemClick",
  "navigationIconClick",
]);

const onClickNavigation = () => {
  emit("navigationIconClick");
};
const onActionClick = (itemKey: string) => {
  devConsoleLog(itemKey);
  emit("actionItemClick", itemKey);
};
const onClickOverFlowMenu = (Key: string) => {
  emit("overFlowMenuItemClick", Key);
  showOverflowIcons.value = !showOverflowIcons.value;
};

let showOverflowIcons = ref(false);

const onMoreVertClick = () => {
  showOverflowIcons.value = !showOverflowIcons.value;
};

const whenToOverflow = computed(() => {
  return props.overflowWhen;
});

const appBarActionItemsList = computed(() => {
  if (props.appBarActionItems?.length === 0) {
    return [];
  }
  if (!props.overflowWhen) return props.appBarActionItems;

  if (props.overflowWhen > 0) {
    return props.appBarActionItems?.slice(0, props.overflowWhen);
  }
});

const popupItems = computed(() => {
  let wto = props.overflowWhen != undefined ? props.overflowWhen : 2;
  if (props.overflowWhen) {
    return props.appBarActionItems?.slice(
      props.overflowWhen,
      props.appBarActionItems.length
    );
  } else {
    return [];
  }
});
const overflowList = ref<HTMLElement | null>(null);
onMounted(() => {
  useOnClickOutside(overflowList, () => {
    if (showOverflowIcons.value) {
      onMoreVertClick();
    }
  });
});
</script>

<template>
  <div class="sk-appbar" :class="{'sk-appbar-shadow': appBarBoxShadow, 'sk-appbar-fixed': sticky}">
    <!-- Top App Bar row :: BEGIN -->
    <div class="sk-appbar-row">
      <div :class="containerFixed ? 'sk-container' : 'sk-container-fluid'">      
        <!-- App bar Starting Section :: BEGIN -->
        <div class="sk-appbar-section sk-appbar-align-start">
          <SkButton :class="showLeftActionWeb ? '' : 'sk-web-hide'"
            round
            noShadow
            :icon="useSvg == false || useSvg == undefined ? appBarLeftIconStyle : ''"
            :svgIcon="useSvg == true && useSvg != undefined ? appBarLeftIconStyle : ''"
            :badge="''"
            v-if="appBarLeftIconStyle !== ''"
            @click="onClickNavigation"
          />
          <!-- App bar title -->
          <div class="appbar-title-group">
            <h4 v-if="appBarTitle !== ''">{{ appBarTitle }}</h4>
            <small class="sk-h8" v-if="appBarSubTitle !== ''">{{ appBarSubTitle }}</small>
          </div>
          <slot name="ableft"></slot>
        </div>
        <!-- App bar Ending Section :: BEGIN -->
        <div class="sk-appbar-section sk-appbar-align-end">
          <!-- Need a slot for a dropdown-->
          <slot name="abright"></slot>
          <div class="sk-button-group">
            <SkButton
              v-for="item in appBarActionItems"
              :key="item.itemKey"
              round
              noShadow
              :webHide="item.webHide"
              :mobileHide="item.mobileHide === false ? false : true"
              :badge="item.badge"
              :badgeType="item.badgeType != undefined ? item.badgeType : ''"
              :svgIcon="
                item.actionIcon !== undefined && useSvg == true && useSvg != undefined
                  ? item.actionIcon
                  : ''
              "
              :icon="
                item.actionIcon !== undefined && (useSvg == false || useSvg == undefined)
                  ? item.actionIcon
                  : ''
              "
              :tooltipType="item.tooltipType"
              @click="onActionClick(item.itemKey)"
            />

            <div class="sk-overflow-menu"  :class="{'sk-hide': !showOverflowIcons}">
              <SkButton
                v-for="item in appBarActionItemsList"
                :key="item.itemKey"
                round
                noShadow
                :webHide="true"
                :mobileHide="isMobileHide"
                :badge="item.badge"
                :badgeType="item.badgeType != undefined ? item.badgeType : ''"
                :svgIcon="
                  item.actionIcon !== undefined && useSvg == true && useSvg != undefined
                    ? item.actionIcon
                    : ''
                "
                :icon="
                  item.actionIcon !== undefined && (useSvg == false || useSvg == undefined)
                    ? item.actionIcon
                    : ''
                "
                :tooltipType="item.tooltipType"
                @click="onActionClick(item.itemKey)"
              >
              </SkButton>
              <SkButton
                v-if="whenToOverflow"
                noShadow
                :webHide="true"
                badge=""
                splbadge="close"
                :svgIcon="useSvg == true && useSvg != undefined ? 'more_vert' : ''"
                :icon="useSvg == false && useSvg == undefined ? 'more_vert' : ''"
                @click="onMoreVertClick"
              >
              </SkButton>
              <ul
                ref="overflowList"
                class="sk-overflow-list"
                :class="{ 'sk-show': showOverflowIcons }"
              >
                <li
                  v-for="item in popupItems"
                  :key="item.itemKey"
                  @click="onActionClick(item.itemKey)"
                >
                  <SkIcon
                    :iconType="
                      item.actionIcon !== undefined &&
                      (useSvg == false || useSvg == undefined)
                        ? item.actionIcon
                        : ''
                    "
                    :svgIcon="
                      item.actionIcon != undefined &&
                      item.actionIcon != '' &&
                      useSvg == true &&
                      useSvg != undefined
                        ? item.actionIcon
                        : ''
                    "
                  >
                  </SkIcon>
                  <SkBadge
                    v-if="item.badge"
                    :badge="item.badge"
                    :badgeType="item.badgeType != undefined ? item.badgeType : ''"
                    :small="true"
                    :danger="true"
                  ></SkBadge>
                  {{ item.actionlabel }}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
