export class SkFetch {
  public baseUrl: string;
  public appHeaders: Headers;

  constructor(baseUrl: string, appHeaders: Headers) {
    this.baseUrl = baseUrl;
    this.appHeaders = appHeaders;
  }

  public setAppHeaders(headers: Headers) {
    this.appHeaders = headers;
  }

  public SetBaseUrl(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  public async Get<T>(
    relUrl: string,
    urlParams?: URLSearchParams,
    ignorebaseUrl: boolean = false,
  ): Promise<T> {

    var apiUrl = (ignorebaseUrl ? "" : this.baseUrl) + relUrl;
    apiUrl += urlParams ? `?${urlParams.toString()}` : "";
    const request: RequestInit = {};
    request.headers = this.appHeaders;
    //  request.credentials = "include";

    return await this.FetchGet(apiUrl, request);

  }

  private async FetchGet<T>(apiUrl: string, request: RequestInit): Promise<T> {

    let result =  await fetch(apiUrl, request)
      .then(response => {
        return response;
      })
      .catch((err) => {
        console.log(err);
        throw err;
      });

      if (!result.ok) {
        if(result.status == 401){

          let UrlBase = '';

          let requestToken: RequestInit = {};

          let accessToken = this.appHeaders.get('usertoken') != null ? this.appHeaders.get('usertoken') as string : '';
          
          requestToken.headers = { usertoken: accessToken };

            let getToken = {} as any;
            let apiUrlGetToken = `${UrlBase}/api/usermanagement/get-new-user-token`;
    
           getToken = await this.FetchGet(apiUrlGetToken, requestToken);
    
            if (getToken.response.isSuccess) {

              if (window.appStateChanged)
                window.appStateChanged(getToken.response.accessToken);

              this.appHeaders.delete("usertoken");
              this.appHeaders.append(
                "usertoken",
                getToken.response.accessToken
              );
              return await this.FetchGet(apiUrl,request);
            }else{
              throw new Error(getToken);
            }

        }else{
          throw new Error(result.statusText);
        }
      }
      return result.json() as Promise<T>;

  }

  // private appStateChanged(newToken: string){

  //   var userStr = localStorage.getItem('pmAppState');

  //   if(userStr) {
  //     var userObject = JSON.parse(userStr);
  //     userObject.userToken = newToken;
  //     localStorage.setItem("pmAppState", userObject);
  //   }
  // }

  public async Post<T>(
    relUrl: string,
    postParams: string | FormData,
    useFormData: boolean = false,
  ): Promise<T> {
    const apiUrl = this.baseUrl + relUrl;
    const body: FormData | string = useFormData
      ? (postParams as FormData)
      : postParams;

    const request: RequestInit = {
      method: FetchMethods.Post.toString(),
      body: body,
    };

    if (!useFormData)
      this.appHeaders.append("Content-Type", ContentTypes.Json.toString());

    request.headers = this.appHeaders;
    
    return await this.FetchPost(apiUrl, request);
      
  }

  private async FetchPost<T>(apiUrl: string, request: RequestInit): Promise<T> {
    let result = await fetch (apiUrl, request)
      .then((response) => {
        return response;
      })
      .catch((err) => {
        console.log(err);
        throw err;
      });

      if (!result.ok) {
        if(result.status == 401){

          let UrlBase = '';

          let requestToken: RequestInit = {};

          let accessToken = this.appHeaders.get('usertoken') != null ? this.appHeaders.get('usertoken') as string : '';
          
          requestToken.headers = { usertoken: accessToken };

            let getToken = {} as any;
            let apiUrlGetToken = `${UrlBase}/api/usermanagement/get-new-user-token`;
    
           getToken = await this.FetchGet(apiUrlGetToken, requestToken);
    
            if (getToken.response.isSuccess) {

              if (window.appStateChanged)
                window.appStateChanged(getToken.response.accessToken);

              this.appHeaders.delete("usertoken");
              this.appHeaders.append(
                "usertoken",
                getToken.response.accessToken
              );
              return await this.FetchPost(apiUrl,request);
            }else{
              throw new Error(getToken);
            }

        }else{
          throw new Error(result.statusText);
        }
      }
      const content = result.headers.get('Content-Type');
      const json = content && content.includes(ContentTypes.Json);
      if (json) return result.json() as Promise<T>;

      return result.text() as unknown as Promise<T>;

  }


  public Put<T>(
    relUrl: string,
    putParams: string | FormData,
    useFormData: boolean = false
  ): Promise<T> {
    const apiUrl = this.baseUrl + relUrl;
    const body: FormData | string = useFormData
      ? (putParams as FormData)
      : putParams;

    const request: RequestInit = {
      method: FetchMethods.Put.toString(),
      body: body,
    };

    if (!useFormData)
      this.appHeaders.append("Content-Type", ContentTypes.Json.toString());

    request.headers = this.appHeaders;
    return fetch(apiUrl, request)
      .then((response) => {
        if (!response.ok) {
          throw new Error(response.statusText);
        }
        return response.json() as Promise<T>;
      })
      .catch((err) => {
        console.log(err);
        throw err;
      });
  }

  public Patch<T>(
    relUrl: string,
    patchParams: string | FormData,
    useFormData: boolean = false
  ): Promise<T> {
    const apiUrl = this.baseUrl + relUrl;
    const body: FormData | string = useFormData
      ? (patchParams as FormData)
      : patchParams;

    const request: RequestInit = {
      method: FetchMethods.Patch.toString(),
      body: body,
    };

    if (!useFormData)
      this.appHeaders.append("Content-Type", ContentTypes.Json.toString());

    request.headers = this.appHeaders;
    return fetch(apiUrl, request)
      .then((response) => {
        if (!response.ok) {
          throw new Error(response.statusText);
        }

        return response.json() as Promise<T>


      })

      .catch((err) => {
        console.log(err);
        throw err;
      });
  }

}

enum ContentTypes {
  Json = "application/json",
  FormUrlEncoded = "application/x-www-form-urlencoded",
  Plain = "text/plain",
  FormData = "multipart/form-data",
}

enum FetchMethods {
  Post = "POST",
  Get = "GET",
  Put = "PUT",
  Patch = "PATCH",
  Delete = "DELETE",
}







