<script lang="ts">
export default {
  name: "SkRadio",
};
</script>
<script setup lang="ts">

interface Props {
  chkid?: string; // Radio button unique id
  radioButtonName?: string; // Radio button name to group set of Radio button items
  labelName?: string; // Add label text to the radio button 
  isChecked?: boolean; //Change the checked attribute to true or false
  disabled?: boolean; // Disabled the checkbox
  helperText?: string; // Add help text
}

const props = defineProps<Props>();
</script>
<template>
  <div class="sk-radio">
    <input
      class="sk-radio-input"
      :name="radioButtonName"
      type="radio"
      :id="'chkid ' + props.chkid"
      :value="props.chkid"
      :checked="isChecked"
      :disabled="disabled"
    />
    <label class="sk-check-label" :for="'chkid ' + props.chkid">
    {{
      labelName
    }}
    <span v-if="helperText" class="sk-helper-text">{{helperText}}</span>
    </label>
  </div>
</template>
