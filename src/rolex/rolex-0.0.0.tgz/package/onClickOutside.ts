import { Ref } from "vue";

export function useEventListener(
  target: EventTarget,
  event: string,
  handler: (e: Event) => any
) {
  target.addEventListener(event, handler);
}

export function useOnClickOutside(
  rootEl: Ref<HTMLElement | null>,
  callback: () => any
) {
  useEventListener(document, "mousedown", (e: Event) => {
    const clickedEl = e.target as Node;
    // skip if the root element contains the clicked element
    if (rootEl.value?.contains(clickedEl)) {
      return;
    }
    // otherwise execute the action
    callback();
  });
}
