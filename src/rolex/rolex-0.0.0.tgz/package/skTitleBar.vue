<script setup lang="ts">
interface prop {
  titleName: string;
  truncate?: boolean;
  subTitle?: string;
}
const props = defineProps<prop>();
</script>
<script setup lang="ts"></script>
<template>
  <div class="sk-title-bar">
    <div class="sk-title-bar-section sk-title-bar-start">
      <div class="sk-title"
        :class="{
          'sk-truncate': truncate,
        }"
      >
        {{ titleName }}
        <span :class="{ 'sk-sub-head': subTitle, 'sk-sub-head sk-hide': !subTitle }">{{
          subTitle
        }}</span>
      </div>
    </div>
    <div class="sk-title-bar-section sk-title-bar-end">
      <slot name="Actions"></slot>
    </div>
  </div>
</template>
