<script setup lang="ts">
import Skbutton from "./skbutton.vue";
import { skActionItem } from "./skglobaltypes";
import { ref } from "vue";
interface prop {
  bottomNavigationItems?: skActionItem[];
  useSvg?:boolean;
}
const props = defineProps<prop>();
const buttonsDatas = ref<skActionItem[]>(props.bottomNavigationItems != undefined ? props.bottomNavigationItems : []);
const emit = defineEmits(["footerNavigator"]);
const footerOnClick = (ClickedFooterValue:skActionItem) => {
  emit("footerNavigator", ClickedFooterValue);
};
</script>
<template>
  <!-- useSvg is the flag which come with a #skactionitem interface , 
    if the flag is true it will accept svg icons otherwise it will accept pm/word icon  -->
  <div class="sk-bottom-nav sk-appbar-shadow">
    <skbutton
      v-for="btn in buttonsDatas"
      :buttonText="btn.actionlabel"
      :icon="useSvg==false||useSvg==undefined?btn.actionIcon:''"
      :svgIcon="useSvg==true&&useSvg!=undefined?btn.actionIcon:''" 
      :class="btn.isActive ? 'sk-active' : ''"
      @click="footerOnClick(btn)"
    ></skbutton>
  </div>
</template>
