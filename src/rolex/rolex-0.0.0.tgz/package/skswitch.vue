<script lang="ts">
export default {
  name: "SkSwitch",
};
</script>
<script setup lang="ts">
import {  HtmlItemSizeOptions } from "./skglobaltypes";

interface Props {   
    isWide?:boolean; 
    isChecked:boolean; //Make default state as on/active

    secondary?:boolean; //Apply secondary color
    link?:boolean; // Apply link color
    success?:boolean; // Apply success color
    warning?:boolean; // Apply Warning color  
    
    size?: HtmlItemSizeOptions; // To define different switch sizes
    
    leadingText?:string; // Add leading text to switch
    trailingText?:string; // Add trailing text to switch
    
    disabled?:boolean // Disable the switch component
}
const props = defineProps<Props>();
const emit = defineEmits(["onChange"])
function onChange() {
  emit("onChange");
}
</script>
<template>
 <div class="sk-switch"
 :class="{
    'sk-switch-wide':isWide,
    'sk-secondary':secondary,
    'sk-link':link,
    'sk-success':success,
    'sk-warning':warning,
    'sk-disabled':disabled,
    'sk-small': size == HtmlItemSizeOptions.Small,
    'sk-large': size == HtmlItemSizeOptions.Large
 }">
<label>
    <span class="sk-leading" v-if="leadingText">{{leadingText}}</span>
    <input type="checkbox" :checked="isChecked" @change="onChange" />
    <span class="lever"><span v-if="isWide" class="sk-icon"></span></span>
    <span class="sk-trailing" v-if="trailingText">{{trailingText}}</span>
</label>
 </div>
</template>