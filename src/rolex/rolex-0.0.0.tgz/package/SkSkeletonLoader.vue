<script setup lang="ts">
import { ref } from "vue";
import { HtmlItemSizeOptions } from "./skglobaltypes";

interface prop {
  show?: boolean;
  size?: HtmlItemSizeOptions;
  skeletonListView?: boolean;
}

const props = defineProps<prop>();

</script>
<template>
  <div v-if="!skeletonListView" class="sk-skeleton-loader" :class="{
      'sk-show': show,
      'sk-small': size == HtmlItemSizeOptions.Small
      }">
      <div class="sk-skeleton-inner">
          <div class="sk-skeleton-row">
            <div class="sk-skeletor sk-skeleton-avatar"></div>
            <div class="sk-skeleton-row-group">
                <div class="sk-skeletor sk-skeleton-line-long"></div>
                <div class="sk-skeletor sk-skeleton-line-short"></div>
            </div>          
          </div>
          <div class="sk-skeletor sk-skeleton-line"></div>
          <div class="sk-skeletor sk-skeleton-line"></div>
          <div class="sk-skeletor sk-skeleton-line"></div>
      </div>
  </div>

  <div v-if="skeletonListView" class="sk-skeleton-loader sk-skeleton-list sk-small" :class="{
      'sk-show': show
      }">
      <div class="sk-skeleton-inner">
          <div class="sk-skeleton-row">
            <div class="sk-skeletor sk-skeleton-avatar"></div>
            <div class="sk-skeleton-row-group">
                <div class="sk-skeletor sk-skeleton-line-long"></div>
                <div class="sk-skeletor sk-skeleton-line-short"></div>
            </div>          
          </div>          
      </div>
  </div>
</template>
