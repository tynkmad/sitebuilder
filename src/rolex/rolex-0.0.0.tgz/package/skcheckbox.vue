<script lang="ts">
export default {
  name: "SkCheckbox",
};
</script>
<script setup lang="ts">
interface Props {
  isCheckbox: boolean; // Default is hidden. To show the checkbox add this props. (TODO:: This should not be default hidden. This props needs to be rewritten.)
  chkid?: string; // Checkbox id should be unique (TODO :: Need to change proper naming)
  checkboxName?: string; // Checkbox name to group set of checkbox items
  labelName?: string; // Add label to the checkbox
  isChecked?: boolean; //Change the checked attribute to true or false
  disabled?: boolean; // Disabled the checkbox
  lever?:boolean;
  hintText?: string; // Add help text
}
const props = defineProps<Props>();
</script>
<template>
  <div
    class="sk-checkbox"
    :class="{ 'sk-show': isCheckbox, 'sk-hide': !isCheckbox }"
  >
    <input
      class="sk-check-input"
      :name="checkboxName"
      :id="'chkid ' + props.chkid"
      type="checkbox"
      v-bind:checked="isChecked"
      :disabled="disabled"
    />
    <label class="sk-check-label" :for="'chkid ' + props.chkid"
      >{{ labelName }}<slot name="labelContent"></slot
    ><span v-if="hintText" class="hint-text">{{hintText}}</span></label>
    <span v-if="lever" class="lever"></span>
  </div>
</template>
