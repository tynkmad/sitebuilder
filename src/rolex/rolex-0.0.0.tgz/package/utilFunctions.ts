import * as XLSX from 'xlsx';
function formatToShort(value: number) {
  if(value && value > 0) {
    if (value >= 10000000) {
      return (value / 10000000).toFixed(2) + 'Cr';
    } else if (value >= 100000) {
      return (value / 100000).toFixed(2) + 'L';
    } else if (value >= 1000) {
      return (value / 1000).toFixed(2) + 'K';
    } else {
      return value.toString();
    }
  } else {
    return '0';
  }
  // return value >= 1000000
  //   ? `${((value / 1000000) * 100 / 100).toFixed(2)}M`
  //   : value >= 1000
  //     ? `${((value / 1000) * 10 / 10).toFixed(2)}K`
  //     : `${value}`;
}

function getStarClass(value: number) {
  return !value
    ? "sk-star0"
    : Number.isInteger(value)
      ? `sk-star${value}`
      : `sk-star${value.toString().charAt(0)}-5`;
}

function getLongestInArrayList(arrayList: Array<any>) {
  // returns the date list which has maximum date values.
  const lengths = arrayList.map((a: any) => a.length);
  return arrayList[lengths.indexOf(Math.max(...lengths))];
}

function toggleBodyNoScroll(scroll?: boolean) {
  scroll
    ? document.body.classList.add("no-scroll")
    : document.body.classList.remove("no-scroll");
}

// Use this for logging console only in developement Environement
function devConsoleLog(logValue: any, label: string = "log:") {
  if (window.location.hostname == "local.promanage.biz") {
    console.log(label, logValue);
  }
}

// Split minutes to Days/Hours/Minutes
function splitMinutesToDHM(minutes: number) {
  var numberOfHours = minutes / 60,
    days = Math.floor(numberOfHours / 24),
    remainder = numberOfHours % 24,
    hours = Math.floor(remainder),
    minutes = Math.floor(60 * (remainder - hours));
  return {
    days,
    hours,
    minutes,
  };
}

function downloadBase64AsPdf(base64: any, fileName: string) {
  var pdfArrayBuffer = _base64ToArrayBuffer(base64);
  var blob = new Blob([pdfArrayBuffer], { type: "application/pdf" }); // change resultByte to bytes

  var link = document.createElement("a");
  link.href = window.URL.createObjectURL(blob);
  link.download = `${fileName}.pdf`;
  link.click();

  function _base64ToArrayBuffer(base64: any) {
    var binary_string = window.atob(base64);
    var len = binary_string.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
      bytes[i] = binary_string.charCodeAt(i);
    }
    return bytes.buffer;
  }
}

function isQAorLocal() {
  return ["qa.promanage.biz", "local.promanage.biz"].includes(
    window.location.hostname
  );
}

function donwloadExcel(excelUrl: string, fileName: string) {
  //Create XMLHTTP Request.
  var req = new XMLHttpRequest();
  req.open("GET", excelUrl, true);
  req.responseType = "blob";
  req.onload = function () {
    //Convert the Byte Data to BLOB object.
    var blob = new Blob([req.response], { type: "application/octetstream" });
    var winUrl = window.URL || window.webkitURL;
    var link = winUrl.createObjectURL(blob);
    var a = document.createElement("a");
    a.setAttribute("download", fileName);
    a.setAttribute("href", link);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };
  req.send();
}

function filterUniqueItemsInArray(array: Array<any>, key: string) {
  return [...new Map(array.map((item) => [item[key], item])).values()];
}

function swapElementsInArray(
  array: Array<any>,
  index1: number,
  index2: number
) {
  array[index1] = array.splice(index2, 1, array[index1])[0];
}

function hasMobileNumberInString(str: string) {
  var num = str.replace(/[^0-9]/g, " ");
  var text = num.split("  ");
  let hasMobileNo = false;
  for (var i = 0; i < text.length; i++) {
    var t = text[i].trim();
    t = t.replace(" ", "");
    var l = t.length;
    if (l >= 10) {
      hasMobileNo = true;
    }
  }
  return hasMobileNo;
}

function navigateToHref(path: string) {
  window.location.href = `${window.location.origin}/${path}`;
}

function downloadJsonAsExcel(jsonData1: any, showLabel: boolean, fileName: string, jsonData2: any = null): void {
  const processJsonData = (jsonData: any): any[] => {
    let arrData = typeof jsonData !== 'object' ? JSON.parse(jsonData) : jsonData;
    return arrData.map((item: any) => {
      for (const key in item) {
        if (key === 'virtualNumber') {
          item[key] = '\t' + item[key];
        } else if (['streetName', 'cityName', 'areaName'].includes(key)) {
          item[key] = '\t' + item[key].replace(/"/g, '');
        }
      }
      return item;
    });
  };

  const arrData1 = processJsonData(jsonData1);
  const worksheet1 = XLSX.utils.json_to_sheet(arrData1);
  const workbook = XLSX.utils.book_new();

  if (showLabel) {
    const headers1: string[] = [];
    for (const index in arrData1[0]) {
      headers1.push(index);
    }
    XLSX.utils.sheet_add_json(worksheet1, arrData1, { skipHeader: true, origin: 'A2' });
  }

  XLSX.utils.book_append_sheet(workbook, worksheet1, jsonData2 && jsonData2.sheet1 ? jsonData2.sheet1 : 'Sheet1');

  if (jsonData2) {
    const arrData2 = processJsonData(jsonData2);
    const worksheet2 = XLSX.utils.json_to_sheet(arrData2);

    if (showLabel) {
      const headers2: string[] = [];
      for (const index in arrData2[0]) {
        headers2.push(index);
      }
      XLSX.utils.sheet_add_json(worksheet2, arrData2, { skipHeader: true, origin: 'A2' });
    }

    XLSX.utils.book_append_sheet(workbook, worksheet2,  jsonData2 && jsonData2.sheet2 ? jsonData2.sheet2 :'Sheet2');
  }

  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([new Uint8Array(excelBuffer)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

  const downloadLink = document.createElement('a');
  const url = URL.createObjectURL(blob);
  downloadLink.href = url;
  downloadLink.download = fileName + '.xlsx';
  document.body.appendChild(downloadLink);
  downloadLink.click();
  document.body.removeChild(downloadLink);
}


function isValidEmailId(emailId: string) {
  let isValid = false;
  emailId.match(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) ? isValid = true : isValid = false;
  return isValid
}
function formatDate(dateString:string) {
  const months = [
    "Jan", "Feb", "Mar", "Apr",
    "May", "Jun", "Jul", "Aug",
    "Sep", "Oct", "Nov", "Dec"
  ];
  
  const date = new Date(dateString);
  const day = date.getDate().toString().padStart(2, "0");
  const month = months[date.getMonth()];
  const year = date.getFullYear().toString().substr(-2);

  return `${day} ${month} ${year}`;
}

async function getMediaAsFileFromUrl(mediaUrl: string, fileName: string) {
  const response = await fetch(mediaUrl);
  const blob = await response.blob();
  const file = new File([blob], fileName, { type: blob.type });
  return file;
}

function timeAgo(timestamp: number, txtLength: 'short' | 'long' = 'long') {
  const currentTime = new Date().getTime();
  const timeDifference = currentTime - timestamp;

  // Define the time units in milliseconds
  const minute = 60 * 1000;
  const hour = 60 * minute;
  const day = 24 * hour;
  const week = 7 * day;
  const month = 30 * day;
  const year = 365 * day;

  const durationName = {
    long: {
      minute: (t: number) => (`minute${t > 1 ? 's' : ''}`),
      hour: (t: number) => (`hour${t > 1 ? 's' : ''}`),
      day: (t: number) => (`day${t > 1 ? 's' : ''}`),
      week: (t: number) => (`week${t > 1 ? 's' : ''}`),
      month: (t: number) => (`month${t > 1 ? 's' : ''}`),
      year: (t: number) => (`year${t > 1 ? 's' : ''}`),
    },
    short: {
      minute: (t: number) => (`min`),
      hour: (t: number) => (`hr`),
      day: (t: number) => (`d`),
      week: (t: number) => (`wk`),
      month: (t: number) => (`m`),
      year: (t: number) => (`y`),
    }
  }

  if (timeDifference < minute) {
    return 'Just now';
  } else if (timeDifference < hour) {
    const minutes = Math.floor(timeDifference / minute);
    return `${minutes} ${durationName[txtLength].minute(minutes)} ago`;
  } else if (timeDifference < day) {
    const hours = Math.floor(timeDifference / hour);
    return `${hours} ${durationName[txtLength].hour(hours)} ago`;
  } else if (timeDifference < week) {
    const days = Math.floor(timeDifference / day);
    return `${days} ${durationName[txtLength].day(days)} ago`;
  } else if (timeDifference < month) {
    const weeks = Math.floor(timeDifference / week);
    return `${weeks} ${durationName[txtLength].week(weeks)} ago`;
  } else if (timeDifference < year) {
    const months = Math.floor(timeDifference / month);
    return `${months} ${durationName[txtLength].month(months)} ago`;
  } else {
    const years = Math.floor(timeDifference / year);
    return `${years} ${durationName[txtLength].year(years)} ago`;
  }
}
function formatAddress(address: string) {
  // Replace multiple consecutive commas with a single comma, then replace any double spaces with a single space
  if (address != null)
    return address.replace(/,+/g, ', ').replace(/ +/g, " ").replace(', ,', ',').trim();
  else
    return address
}
export {
  formatToShort,
  getStarClass,
  getLongestInArrayList,
  toggleBodyNoScroll,
  devConsoleLog,
  splitMinutesToDHM,
  downloadBase64AsPdf,
  isQAorLocal,
  donwloadExcel,
  filterUniqueItemsInArray,
  swapElementsInArray,
  hasMobileNumberInString,
  navigateToHref,
  downloadJsonAsExcel,
  isValidEmailId,
  formatDate,
  getMediaAsFileFromUrl,
  timeAgo,
  formatAddress
};
