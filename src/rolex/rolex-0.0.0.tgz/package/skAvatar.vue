<script setup lang="ts">
import { computed } from "vue";
import {  HtmlItemSizeOptions } from "./skglobaltypes";
import skIcon from "./skicon.vue";

interface prop {

  // Base
  text?: string; // Show avatar name's first letter
  rounded?: boolean; // Show rounded corner radius image thumbnail
  size?: HtmlItemSizeOptions; // Different sizes of avatar.

  // Photo 
  photoUrl?: string; // Show avatar profile picture. 
  altText?: string; // Add photo alt text. 
  titleText?: string; // Add photo title text.  
  width?: string // Add photo width. 
  height?: string // Add photo height. 

  // Badge
  badge?: string | boolean; // Add badge in avatar
  badgeIcon?: string; // Add icon in badge with avatar

  // No photo case
  isIconRequired?: boolean; // true to select icon / flase to select text version for no photo case
  icon?: string; // Show alternate icon when actual profile photo not available
  iconLabel?: string // Show no photo use case label
  useSvg?:boolean; // Add "useSvg" props whenever we use svg for icons

}

const props = defineProps<prop>();
const avatarNameDisplay = computed(() => {
  if (props.text != undefined) {
    return props.text.charAt(0);
  }
});
</script>
<template>
  <div class="sk-avatar" :class="{
    'sk-rounded': rounded,
    'sk-small': size == HtmlItemSizeOptions.Small,
    'sk-large': size == HtmlItemSizeOptions.Large
  }">
    <span class="sk-avatar-title" v-if="!photoUrl && !isIconRequired">{{ avatarNameDisplay }}</span>
    
    <img v-if="photoUrl" :src="photoUrl" :alt="altText" :title="titleText" :width="width" :height="height"
      class="sk-image" />

    <div class="sk-badge" v-if="badge || badgeIcon">
      <skIcon v-if="badgeIcon" :iconType="(useSvg==false) ? badgeIcon:''"  :svgIcon="(useSvg==true) ? badgeIcon:''"   iconSize="large"></skIcon>
      {{ typeof badge == "boolean" ? "" : (badge ? badge : "") }}
    </div>

    <div class="sk-avatar-icon" v-if="isIconRequired == true && (photoUrl == undefined || photoUrl?.length <= 0)">
      <skIcon :iconType="(useSvg==false) ? icon:''"  :svgIcon="(useSvg==true) ? icon:''"   iconSize="large"></skIcon>
      <span class="sk-avatar-label" v-if="iconLabel">{{ iconLabel }}</span>
    </div>
    
  </div>
</template>