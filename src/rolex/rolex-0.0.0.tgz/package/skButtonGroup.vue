<script lang="ts">
export default {
    name: "SkButtonGroup",
    components: { Skbutton, Skpopup }
};
</script>
<script setup lang="ts">
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup

import Skbutton from "./skbutton.vue";
import { ISkButton, skActionItem } from "./skglobaltypes"
import Skpopup from "./skpopup.vue";

interface Props {
    buttonGroup: Array<ISkButton>,
    justifyEnd?: boolean,
    overFlowItems?: Array<skActionItem>,
    overFlowItemAction?: (key: string) => any
}


let props = defineProps<Props>();

function onOverSelect(key: string) {
    if (props.overFlowItemAction)
        props.overFlowItemAction(key);
}

</script>
<template>
    <div class="sk-button-group" :class="{
        'sk-flex-justify-end': justifyEnd
    }">
        <!-- Note: Add Button props as required -->
        <!-- TODO Include tooltip -->
        <Skbutton v-for="button in buttonGroup" :button-text="button.buttonText" :primary="button.primary"
            :outline="button.outline" :disabled="button.disabled" :round="button.round" :icon="button.icon"  :rounded="button.rounded"
            :no-shadow="button.noShadow" :tooltip-type="button.tooltipType" :hide="button.hide" :link-text="button.linkText" :small="button.small"
            :flat="button.flat"
            @click="button.action" />
        <Skpopup v-if="overFlowItems" :popup-action-items="overFlowItems" @overflow-menu-click="onOverSelect"
            :trigger-button="{
                round: true,
                noShadow: true,
                badgeType: 'icon',
                icon: 'more_vert',
                outline: true,
                action: () => { }
            }" />
    </div>
</template>
