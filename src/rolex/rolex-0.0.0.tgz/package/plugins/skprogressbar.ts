import { stringify } from "querystring";
import { reactive, nextTick, App } from "vue";
import View from "./skprogressbar.vue";
import type { InjectionKey } from "vue";

export interface skProgressOptions {
  canSuccess: boolean;
  show: boolean;
  color: string;
  position: string;
  failedColor: string;
  thickness: string;
  transition: {
    speed: string;
    opacity: string;
    termination: number;
  };
  autoRevert: boolean;
  location: string;
  inverse: boolean;
  autoFinish: boolean;
}

export interface skProgressBarState {
  tFailColor: string;
  tColor: string;
  timer: NodeJS.Timer | undefined;
  cut: number;
}

export interface skProgressBarInjected {
  percent: number;
  options: skProgressOptions;
}
export class skProgressBarPlugin {
  install(app: App, options: skProgressOptions) {
    let defaultOptions = {
      canSuccess: true,
      show: false,
      color: "#73ccec",
      position: "fixed",
      failedColor: "red",
      thickness: "2px",
      transition: {
        speed: "0.2s",
        opacity: "0.6s",
        termination: 300,
      },
      autoRevert: true,
      location: "top",
      inverse: false,
      autoFinish: true,
    };

    if (options == undefined) options = defaultOptions;

    const SK_LOADING_BAR: skProgressBarInjected = reactive({
      percent: 0,
      options: options,
    });

    app.provide("SK_LOADING_BAR", SK_LOADING_BAR);

    let Progress = {
      state: {
        tFailColor: "",
        tColor: "",
        timer: setInterval(() => {}),
        cut: 0,
        tLocation: "",
        tTransition: { speed: "", opacity: "", termination: 300 },
        ttColor: "",
      },
      start(time: number) {
        if (!time) time = 3000;
        SK_LOADING_BAR.percent = 0; // SK_LOADING_BAR.percent
        SK_LOADING_BAR.options.show = true;
        SK_LOADING_BAR.options.canSuccess = true;
        this.state.cut = 10000 / Math.floor(time);
        clearInterval(Progress.state.timer);
        this.state.timer = setInterval(() => {
          this.increase(this.state.cut * Math.random());
          if (
            SK_LOADING_BAR.percent > 95 &&
            SK_LOADING_BAR.options.autoFinish
          ) {
            this.finish();
          }
        }, 100);
      },
      set(num: number) {
        SK_LOADING_BAR.options.show = true;
        SK_LOADING_BAR.options.canSuccess = true;
        SK_LOADING_BAR.percent = Math.floor(num);
      },
      get() {
        return Math.floor(SK_LOADING_BAR.percent);
      },
      increase(num: number) {
        SK_LOADING_BAR.percent = Math.min(
          99,
          SK_LOADING_BAR.percent + Math.floor(num)
        );
      },
      decrease(num: number) {
        SK_LOADING_BAR.percent = SK_LOADING_BAR.percent - Math.floor(num);
      },
      hide() {
        clearInterval(this.state.timer);
        this.state.timer = setInterval(() => {});
        setTimeout(() => {
          SK_LOADING_BAR.options.show = false;
          nextTick(() => {
            setTimeout(() => {
              SK_LOADING_BAR.percent = 0;
            }, 100);
            if (SK_LOADING_BAR.options.autoRevert) {
              setTimeout(() => {
                this.revert();
              }, 300);
            }
          });
        }, SK_LOADING_BAR.options.transition.termination);
      },
      pause() {
        clearInterval(this.state.timer);
      },
      finish() {
        SK_LOADING_BAR.percent = 100;
        this.hide();
      },
      fail() {
        SK_LOADING_BAR.options.canSuccess = false;
        SK_LOADING_BAR.percent = 100;
        this.hide();
      },
      setFailColor(color: string) {
        SK_LOADING_BAR.options.failedColor = color;
      },
      setColor(color: string) {
        SK_LOADING_BAR.options.color = color;
      },
      setLocation(loc: string) {
        SK_LOADING_BAR.options.location = loc;
      },
      setTransition(transition: any) {
        SK_LOADING_BAR.options.transition = transition;
      },
      tempFailColor(color: string) {
        this.state.tFailColor = SK_LOADING_BAR.options.failedColor;
        SK_LOADING_BAR.options.failedColor = color;
      },
      tempColor(color: string) {
        this.state.tColor = SK_LOADING_BAR.options.color;
        SK_LOADING_BAR.options.color = color;
      },
      tempLocation(loc: string) {
        this.state.tLocation = SK_LOADING_BAR.options.location;
        SK_LOADING_BAR.options.location = loc;
      },
      tempTransition(transition: any) {
        this.state.tTransition = SK_LOADING_BAR.options.transition;
        SK_LOADING_BAR.options.transition = transition;
      },
      revertColor() {
        SK_LOADING_BAR.options.color = this.state.tColor;
        this.state.tColor = "";
      },
      revertFailColor() {
        SK_LOADING_BAR.options.failedColor = this.state.tFailColor;
        this.state.tFailColor = "";
      },
      revertLocation() {
        SK_LOADING_BAR.options.location = this.state.tLocation;
        this.state.tLocation = "";
      },
      revertTransition() {
        SK_LOADING_BAR.options.transition = this.state.tTransition;
        this.state.tTransition = { speed: "", opacity: "", termination: 300 };
      },
      revert() {
        if (SK_LOADING_BAR.options.autoRevert) {
          if (this.state.tColor) {
            this.revertColor();
          }
          if (this.state.tFailColor) {
            this.revertFailColor();
          }
          if (this.state.tLocation) {
            this.revertLocation();
          }
          if (
            this.state.tTransition &&
            (this.state.tTransition.speed !== undefined ||
              this.state.tTransition.opacity !== undefined)
          ) {
            this.revertTransition();
          }
        }
      },
      parseMeta(meta: any) {
        for (var x in meta.func) {
          let func = meta.func[x];
          switch (func.call) {
            case "color":
              switch (func.modifier) {
                case "set":
                  this.setColor(func.argument);
                  break;
                case "temp":
                  this.tempColor(func.argument);
                  break;
              }
              break;
            case "fail":
              switch (func.modifier) {
                case "set":
                  this.setFailColor(func.argument);
                  break;
                case "temp":
                  this.tempFailColor(func.argument);
                  break;
              }
              break;
            case "location":
              switch (func.modifier) {
                case "set":
                  this.setLocation(func.argument);
                  break;
                case "temp":
                  this.tempLocation(func.argument);
                  break;
              }
              break;
            case "transition":
              switch (func.modifier) {
                case "set":
                  this.setTransition(func.argument);
                  break;
                case "temp":
                  this.tempTransition(func.argument);
                  break;
              }
              break;
          }
        }
      },
    };

    app.component("sk-progress-bar", View);
    app.config.globalProperties.$Progress = Progress;
  }
}
