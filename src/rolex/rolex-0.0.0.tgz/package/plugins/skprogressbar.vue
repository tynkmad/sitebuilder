<template>
  <div :style="finalStyle"></div>
</template>
<script lang="ts">
export default {
  name: "SkProgressBar",
};
</script>
<script setup lang="ts">
import { inject, computed, StyleValue, CSSProperties } from "vue";
import type { skProgressBarInjected, skProgressOptions } from "./skprogressbar";

let defaultOptions = {
  canSuccess: true,
  show: false,
  color: "#73ccec",
  position: "fixed",
  failedColor: "red",
  thickness: "2px",
  transition: {
    speed: "0.2s",
    opacity: "0.6s",
    termination: 300,
  },
  autoRevert: true,
  location: "top",
  inverse: false,
  autoFinish: true,
};

const progress = inject<skProgressBarInjected>("SK_LOADING_BAR", {
  percent: 0,
  options: defaultOptions,
});

const finalStyle = computed(() => {
  const options = progress.options;
  const isShow = !!options.show;
  const location = options.location;
  const style: CSSProperties = {
    "z-index": 999999,
    "background-color": options.canSuccess ? options.color : options.failedColor,
    opacity: options.show ? 1 : 0,
    position: options.position as any,
    top: "0px",
    bottom: "0px",
    left: "0px",
    right: "0px",
    width: "0px",
    height: "0px",
    transition: "",
  };
  if (location === "top" || location === "bottom") {
    location === "top" ? (style.top = "0px") : (style.bottom = "0px");
    if (!options.inverse) {
      style.left = "0px";
    } else {
      style.right = "0px";
    }
    style.width = progress.percent + "%";
    style.height = options.thickness;
    style.transition =
      (isShow ? "width " + options.transition.speed + ", " : "") +
      "opacity " +
      options.transition.opacity;
  } else if (location === "left" || location === "right") {
    location === "left" ? (style.left = "0px") : (style.right = "0px");
    if (!options.inverse) {
      style.bottom = "0px";
    } else {
      style.top = "0px";
    }
    style.height = progress.percent + "%";
    style.width = options.thickness;
    style.transition =
      (isShow ? "height " + options.transition.speed + ", " : "") +
      "opacity " +
      options.transition.opacity;
  }
  return style;
});
</script>
