<script lang="ts">
export default {
    name: "SkAlert",
};
</script>

<script setup lang="ts">
// define all the customizable properties
interface Props {
    primary?: boolean,
    secondary?: boolean,
    success?: boolean,
    danger?: boolean,
    warning?: boolean,
    info?: boolean,
    light?: boolean,
    dark?: boolean,
    isNotificationBar?: boolean
}

defineProps<Props>();
</script>

<template>
    <div class="sk-alert" :class="{
    'sk-primary': primary,
    'sk-secondary': secondary,
    'sk-success': success,
    'sk-danger': danger,
    'sk-warning': warning,
    'sk-info': info,
    'sk-light': light,
    'sk-dark': dark,
    'sk-notification-bar': isNotificationBar
}">
        <slot></slot>
    </div>
</template>
