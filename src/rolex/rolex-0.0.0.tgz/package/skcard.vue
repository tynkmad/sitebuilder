<script lang="ts">
export default {
  name: "SkCard",
};
</script>

<script setup lang="ts">
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup

interface Props {
  cardstyle?: string; // Need to check and remove if not required
  cardStatus?: boolean; // Need to check and remove if not required  
  media?: boolean; // Need to check and remove if not required
  primary?: boolean; // Need to check and remove if not required
  secondary?: boolean; // Need to check and remove if not required
  actions?: boolean; // Need to check and remove if not required
  label?: string; // Need to check and remove if not required  

  
  cardOutlined?: boolean; // Enable outlined card style
  elevated?: boolean; // Enable elevated card style
  filled?: boolean; // Enable filled card style
  disabled?: boolean; // Need to check and remove if not required
  // active?: boolean;
  cardSelected?: boolean;
  stickyTopScroll?: boolean;
}

defineProps<Props>();
</script>

<template>
  <div class="sk-card" 
  :class="{ 
    'sk-card-elevated': elevated,
    'sk-card-outlined': cardOutlined,
    'sk-card-Filled': filled,
    'sk-disabled': disabled, 
    'sk-card-selected': cardSelected,    
    }"
  >
    <div class="sk-card-media">
      <slot name="skcMedia"></slot>
    </div>

    <div class="sk-card-primary" :class="{
      'sticky-top-scroll': stickyTopScroll
    }">
      <slot name="skcPrimary"></slot>
    </div>

    <div class="sk-card-secondary">
      <slot name="skcSecondary"></slot>
    </div>

    <div class="sk-chart-area">
      <slot name="SkcChart"></slot>
    </div>

    <div class="sk-card-content">
      <slot name="SkcCardContent"></slot>
    </div>

    <div class="sk-card-actions">
      <slot name="skcActions"></slot>
    </div>
    
  </div>
</template>