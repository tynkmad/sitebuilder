<script lang="ts">
export default {
  name: "SkDrawer",
};
</script>

<script setup lang="ts">
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup

import { computed, ref, watch } from "vue";
import { toggleBodyNoScroll } from "./utilFunctions";

interface Props {
  id?: string;
  drawerstyle?: string;

  showDrawer?: boolean;
  right?: boolean;
  left?: boolean;
}

const props = defineProps<Props>();

function closePanel() {
  emit("closePanel");
}

const emit = defineEmits(["closePanel"]);

// const HtmlBody = ref(document.getElementsByTagName("body")[0]);
// const showHideDrawer = computed(() => {
//   if (props.showDrawer) {
//     HtmlBody.value.setAttribute("class", "sk-disabled-scroll");
//   } else if (props.showDrawer == false || props.showDrawer == undefined) {
//     HtmlBody.value.classList.remove("sk-disabled-scroll");
//   }
//   return props.showDrawer;
// });

watch(props, () => {
	toggleBodyNoScroll(props.showDrawer);
});
</script>

<template>
  <div
    class="sk-drawer"
    :class="{
      'sk-drawer-right': right,
      'sk-drawer-left': left,
      'sk-show': showDrawer,
    }"
    :id="id"
  >
    <div class="sk-drawer-container">
      <div class="sk-drawer-inner">
        <div class="sk-drawer-header">
          <slot name="skdrawerheader"></slot>
        </div>

        <div class="sk-drawer-body">
          <slot name="skdrawerbody"></slot>
        </div>
        <div class="sk-drawer-footer">
          <slot name="skdrawerfooter"></slot>
        </div>
      </div>
    </div>
    <div class="sk-backdrop" @click="closePanel"></div>
  </div>
</template>
