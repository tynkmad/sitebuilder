<script lang="ts">
export default {
  name: "SkDialog",
};
</script>

<script setup lang="ts">
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup

import { watch } from 'vue';
import { toggleBodyNoScroll } from "./utilFunctions";

interface Props {
  id?: string;
  // "dialogstyle" props not in use. Check the usage if not required remove.
  dialogstyle?: string;
  showDialog?: boolean;
}

function closeDialog() {
  emit("closeDialog");
}

const emit = defineEmits(["closeDialog"]);
const props = defineProps<Props>();

// const HtmlBody = ref(document.getElementsByTagName("body")[0]);
// const showHideDialog = computed(() => {
//   if (props.showDialog) {
//     HtmlBody.value.setAttribute("class", "sk-disabled-scroll");
//   } else if (
//     props.showDialog == false ||
//     props.showDialog == undefined
//   ) {
//     HtmlBody.value.classList.remove("sk-disabled-scroll");
//   }
//   return props.showDialog;
// });

watch(props, () => {
  toggleBodyNoScroll(props.showDialog);
})
</script>

<template>
  <div class="sk-dialog" :class="{ 'sk-show': showDialog}" :id="id">
    <div class="sk-dialog-container">
      <div class="sk-dialog-inner">
        <div class="sk-dialog-header">
          <slot name="skdialogheader"></slot>
        </div>
        <div class="sk-dialog-body">
          <slot name="skdialogbody"></slot>
        </div>
        <div class="sk-dialog-footer">
          <slot name="skdialogfooter"></slot>
        </div>
      </div>
    </div>
    <div class="sk-backdrop" @click="closeDialog()">
      <!-- Note: No contents allowed. Actionable area. When clicked, the parent container gets dismissed. Used in panels, modals, bottomsheets, dialogs, nav drawers etc. -->
    </div>
  </div>
</template>
