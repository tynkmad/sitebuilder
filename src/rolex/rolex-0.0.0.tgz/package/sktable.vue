<script lang="ts">
export default {
    name: "SkTable",
    components: { Skcheckbox, Skdropdown }
};
</script>
<script setup lang="ts">
import Skcheckbox from './skcheckbox.vue';
import Skdropdown from './skdropdown.vue';
import { ITable, ITableHead, listItemType } from './skglobaltypes';
import SkTableData from './sktabledata.vue';
import SkSkeletonLoader from "./SkSkeletonLoader.vue";

interface Props {
    prop: ITable;
    showLoader? : boolean;
}

let props = defineProps<Props>()


function performHeaderAction(head: ITableHead) {
    if (head.sortable) {
        head.isAscending = head.isAscending == undefined ? true : !head.isAscending; // Toggle Between Ascending and Descending
        head.noSort = false;
        (props.prop.header as Array<ITableHead>).filter(x => x.title != head.title && head.sortable).forEach(y => y.noSort = true); // Disable Active Class for other headers.

        if (head.action) head.action(head);
    }
}

function performHeaderCheckboxAction(head: ITableHead) {
    if (head.checkBox) {
        head.isChecked = !head.isChecked;
        if (head.action) head.action(head);
    }
}

function performDropDownAction(item: listItemType) {

}

</script>

<template>
    <div class="sk-data-table" :class="{
        'flat-table': props.prop.flat,
        'sk-table-striped': props.prop.striped,
        'sk-table-hover': props.prop.hover
    }">
    
    <SkSkeletonLoader   :show="props.showLoader"></SkSkeletonLoader> 
           
        <table>
            <thead>
                <tr>
                    <th v-if="props.prop.defaultHeader" v-for="head in props.prop.defaultHeader">{{ head }}</th>

                    <th @click="performHeaderAction(head)" v-if="props.prop.header" v-for="head in prop.header"
                        :class="{
                            'sk-hide': head.hide, 'sortable': head.sortable, 'active-ascending': head.isAscending && !head.noSort,
                            'active-decending': (head.isAscending != undefined && !head.isAscending) && !head.noSort
                        }" v-bind:class="head.additionalStyle">
                        <Skcheckbox v-if="head.checkBox" :disabled="head.disable" :is-checkbox="head.checkBox"
                            :chkid="`thChk_${Math.random()}`" :is-checked="head.isChecked"
                            @change="performHeaderCheckboxAction(head)" @click.stop />
                        <div v-else-if="head.image" class="sk-flex">
                            <img :src="head.image"> {{ head.title }}
                        </div>
                        <!-- Note: Add Dropdown props if required -->
                        <Skdropdown v-else-if="head.dropDown" :list-items="head.dropDown.listItems"
                            :place-holder-text="head.dropDown.placeHolderText"
                            :show-channel-image="head.dropDown.showChannelImage"
                            :hasFloatingLabel="head.dropDown.hasFloatingLabel"
                            @update:modelValue="performDropDownAction" />
                        <div v-else>{{ head.title }}</div>

                    </th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="row in prop.rows" :class="{ 'sk-hide': row.hide }">
                    <SkTableData v-for="td in row.tableDataList" :prop="td"></SkTableData>
                </tr>
            </tbody>

        </table>
    </div>
</template>