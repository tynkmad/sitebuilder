<script lang="ts">
export default {
  name: "SkFloatingDialog",
};
</script>

<script setup lang="ts">
import { reactive, ref } from "@vue/reactivity";
import { watch } from "vue";
import SkButton from "./skbutton.vue";
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup

interface Props {
  id?: string;
  noShadow?: boolean;
  round?: boolean;
  icon?: string;
  tooltipType?: string;
  buttonText?: string;
}

const props = defineProps<Props>();

interface IReactiveData {
  openDialog: boolean;
}

// set initial defaults
let dataDefaults: IReactiveData = {
  openDialog: false,
};

const emit = defineEmits(["dialogListener"]);
function btnClick() {
  if (ReactiveData.openDialog) hide();
  else show();
}

function show() {
  ReactiveData.openDialog = true;
  emit("dialogListener", ReactiveData.openDialog);
}

function hide() {
  ReactiveData.openDialog = false;
  emit("dialogListener", ReactiveData.openDialog);
}

defineExpose({
  btnClick,
  show,
  hide,
});

let ReactiveData = reactive(dataDefaults);
</script>
<template>
  <div class="sk-floating-dialog" :id="id">
    <div class="sk-select-event">
      <SkButton
        @click="btnClick"
        :icon="icon"
        :tooltipType="tooltipType"
        :buttonText="buttonText"
        noShadow
        round
      />
    </div>
    <div
      class="sk-dialog-container"
      :class="{ 'sk-show': ReactiveData.openDialog }"
      id="emojiPicker"
    >
      <div class="sk-dialog-inner">
        <slot name="dialoginner"></slot>
      </div>
      
    </div>
  </div>
</template>