<script setup lang="ts">
interface prop{
    active?:boolean;
}
const props=defineProps<prop>();
</script>
<template>
    <li class="sk-carousel-item" :class="{'sk-active':active}">
        <slot ></slot>
    </li>
</template>