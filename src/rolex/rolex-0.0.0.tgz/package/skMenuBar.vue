<script lang="ts">
export default {
  name: "SkMenuBar",
  methods: {
    setActive() {
      // Code to set clicked menu item active.
    },
  },
  components: { Channelimg }
};
</script>
<script setup lang="ts">
import { reactive, ref } from "vue";
import { MediumType } from "./SkTypes";
import Channelimg from "./channelimg.vue";
import { HtmlItemSizeOptions, MainNavBarType } from "./skglobaltypes";
import SkIcon from "./skicon.vue";

interface Props {
  MenuItems: Array<MainNavBarType>;
  scrollable?: boolean;
  bgColor?: boolean;
  sticky?: boolean;
  stickyTopLevel?: string;
  enableAnchorTag?: boolean; // Need to check and remove if not required
  hideMenuItemName?: string;
  stickyTopScroll?: boolean;
  useSmallMenu?: boolean;
}

const emit = defineEmits(["navBarNavigation"]);
const onClickToTiggerNav = (index: number) => {
  // const mainNav: any = reactive(document.querySelector(".sk-menu ul"));
  // let navItem: any = document.querySelector(`#nav-${index - 1}-`);
  // mainNav.scrollLeft = navItem.offsetLeft  
};
const navBarOnclick = ((NavId?: string) => {
  emit("navBarNavigation", NavId);
})
defineExpose({
  onClickToTiggerNav
})

const props = defineProps<Props>();
const stickyPosition = ref<string>(
  props.stickyTopLevel ? "sk-sticky-top-" + props.stickyTopLevel : ""
);
</script>

<template>
  <div v-bind:class="stickyPosition" :class="{
    'sk-menu': true,
    'sk-scrollable': scrollable,
    'sk-bg-white': bgColor == true,
    'sk-sticky': sticky,
    'sk-small': useSmallMenu,
  }">
    <nav>
      <ul>
        <li 
          v-for="(item, index) in MenuItems"
          :id="'nav-' + index + '-' + item.targetContentID"
          :key="index"
          :class="{ 
            'sk-active': item.isActive, 
            'sk-hide': item.menuName == hideMenuItemName,
            'sk-disabled': item.isDisabled 
          }"
          @click="navBarOnclick(item.targetContentID as string),
          onClickToTiggerNav(index)"
          >
          <a>
            <figure v-if="item.image">
              <Channelimg :channel="item.image" />
            </figure>
            
            <SkIcon v-if="item.icon" :icon-type="item.icon" ></SkIcon>
            {{ item.menuName }}
            <span class="sk-ripple-container"></span>
          </a>
          <div class="sk-menu-indicator"></div>          
        </li>
      </ul>
    </nav>
  </div>
</template>
