<script lang="ts">
export default {
  name: "SkToast",
};
</script>
<script setup lang="ts">
import { ISlkToast, ToastType, ISlkToastOptions } from "./skglobaltypes";
import { reactive, ref } from "vue";
import { devConsoleLog } from "./utilFunctions";

interface Props {
  iconStyle?: string;
}

const props = defineProps<Props>();

//  let block = new ShowHide()
let visibility = ref(false);
let message = ref("");
let toastObject = ref({} as ISlkToast);
let hasOptions = ref(false);
let hasActions = ref(false);
const defaultToast: ISlkToast = {
  message: "Oops!!",
  interval: 10000,
  type: ToastType.Default,
  options: {
    actions: [
      { text: "open", actionCallback: "openAddUser" },
      { text: "cancel", actionCallback: "openAddUser" },
    ],
  },
};
const showToast = (toast: ISlkToast = {} as ISlkToast): void => {
  toastObject.value = Object.keys(toast).length === 0 ? defaultToast : toast;
  //Check if the toast has any options
  hasOptions.value =
    "options" in toastObject && toastObject.value["options"] !== undefined;
  if (hasOptions.value) checkToastOptions();
  visibility.value = true;
  message.value = toastObject.value.message;
  devConsoleLog(toast.message, "Show Toast");
  //Dismiss the toast after a certain interval
  setTimeout(() => {
    dismissToast();
  }, toastObject.value.interval);
};
//Manipulate and check for all toast options
const checkToastOptions = () => {
  //Check if the toast has any actions and callbacks
  // @ts-ignore: Object is possibly 'null'.
  hasActions.value = hasOptions && toastObject.value.options.actions.length > 0;
};
const dismissToast = (): void => {
  visibility.value = false;
};
const emit = defineEmits(["callbackEvent"]);
function callback(callbackEvent: any) {
  emit(callbackEvent);
  dismissToast();
}
defineExpose({
  showToast,
});
</script>
<template>
  <div
    class="sk-toast"
    @click="dismissToast"
    v-bind:class="{ 'sk-hide': !visibility }"
  >
    <div class="sk-toast-container">
      <span v-if="iconStyle != ''" class="sk-icons">{{ iconStyle }}</span>
      <div class="sk-toast-label">{{ message }}</div>
      <div class="sk-toast-action" v-if="hasActions">
        <div v-for="action in toastObject.options?.actions" :key="action.text">
          <a
            @click="callback(action.actionCallback)"
            class="sk-button sk-small sk-secondary-text"
            >{{ action.text }}</a
          >
        </div>
      </div>
    </div>
  </div>
</template>
