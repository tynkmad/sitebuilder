<script lang="ts">
export default {
  name: "SkTooltip",
};
</script>

<script setup lang="ts">
import { ToolTipDirection } from "./SkTypes";

interface Props {
  show?: boolean;
  direction?: ToolTipDirection;
  isLightBackground?: boolean;
  isRichTooltip?: boolean;
}

const props = defineProps<Props>();
</script>
<template>
  <div :class="`sk-tooltip-rich sk-tooltip-${direction}`">
    <div class="sk-tooltip-trigger">
      <slot name="SkTooltip"></slot>
    </div>
    <div
      class="sk-tooltip-wrapper"
      :class="{
        'sk-light':isLightBackground,
        'sk-tooltip-rich-enabled':isRichTooltip,
        'sk-show': show,
        'sk-hide': !show,
      }"
    >
      <div class="sk-tooltip-inner">
        <slot name="SkTooltipContent"></slot>
      </div>
    </div>
  </div>
</template>
