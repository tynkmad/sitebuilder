<script setup lang="ts">
import { ref } from "vue";
import { HtmlItemSizeOptions } from "./skglobaltypes";

interface prop {
  // Variants
  linearIndeterminate?: boolean; // Linear Interminate varient
  linearDeterminate?: boolean; // Linear Determinate varient
  determinateIndicator?: number; // This is applicable only for Linear
  dotLoader?: boolean;
  loaderCaptionText?: string;

  gifUrl?: string; // Gif ulr & Gif varient
  // Type
  cover?: boolean; // Full page cover loader with backdrop
  surface?: boolean; // Surface section over loader with backdrop
  // Size
  size?: HtmlItemSizeOptions; // Different sizes of loader.
  //Show or hide
  show?: boolean;

  //Overlay
  lightBackdrop?: boolean; // Add light overlay based on the condition
}

const props = defineProps<prop>();

// const showHideLoader = ref(props.show);

// const setLoaderSate = (state: boolean) => {
//   showHideLoader.value = state
// }
// defineExpose({
//   setLoaderSate
// })
</script>
<template>
  <div class="sk-loader" :class="{
    'sk-loader-surface': surface,
    'sk-loader-cover': cover,
    'sk-light-backdrop': lightBackdrop,
    'sk-show': show,
    'sk-small': size == HtmlItemSizeOptions.Small,
    'sk-large': size == HtmlItemSizeOptions.Large,
    'sk-xlarge': size == HtmlItemSizeOptions.ExtraLarge,
  }">
    <div class="sk-loader-inner">
      <!-- Spinner loader :: BEGIN -->
      <div class="sk-spinner-loader" v-if="!linearIndeterminate && !linearDeterminate && !gifUrl && !dotLoader">
        <svg class="sk-circular" viewBox="25 25 50 50">
          <circle class="sk-path" cx="50" cy="50" r="20" fill="none" stroke-miterlimit="10"></circle>
        </svg>
      </div>
      <!-- Spinner loader :: END -->

      <!-- Gif Animated loader :: BEGIN -->
      <div class="sk-gif-loader" v-if="gifUrl">
        <img class="sk-image" :src="gifUrl" />
      </div>
      <!-- Gif Animated loader :: END -->

      <!-- Linear loader :: Interminate :: BEGIN -->
      <div class="sk-linear-loader" v-if="linearIndeterminate">
        <div class="sk-linear-indeterminate"></div>
      </div>
      <!-- Linear loader :: Interminate :: END -->

      <!-- Linear loader :: Determinate :: BEGIN -->
      <div class="sk-linear-loader" v-if="linearDeterminate">
        <div class="sk-linear-determinate" :style="`width:${determinateIndicator}%`"></div>
      </div>
      <!-- Linear loader :: Determinate :: END -->

      <!-- Dot Animated loader :: BEGIN -->
      <div class="sk-dot-loader" v-if="dotLoader">
      </div>
      <!-- Dot Animated loader :: END -->
  <div class="sk-loader-text">{{ loaderCaptionText }}</div>
    </div>
  </div>
</template>
