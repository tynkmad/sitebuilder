<script lang="ts">
export default {
  name: "SkEmptyState",
};
</script>

<script setup lang="ts">
import { skActionItem } from "./skglobaltypes";
import Skicon from "./skicon.vue";
import Skbutton from "./skbutton.vue";

interface Props {
  
  emptyStateStyle?: string; // TODO::This is not in use, we can check and remove this
  emptyStateMedia?: string; // TODO:: Need to check and remove if not required
  // bgColor?: boolean; // This can be removed, handled different way
  // surface?: boolean; // This can be removed, handled different way
  imgUrl?: string; // TODO :: This is duplicate, this canbe removed.

  
  id?: string;
  showEmptyState?: boolean;// Show Empty state
  emptyStateImage?: string; // Add empty state image
  icon?: string; // Add icon to the empty state
  content?: string; // Add content to the empty state
  contentTitle?: string; // Add content title to the empty state
  emptyStateButton?: skActionItem[]; // Add empty state action button
}

const props = defineProps<Props>();
const emit = defineEmits(["emptyStateEmition"]);
const onClickEmptyState = (onClickValue: skActionItem) => {
  emit("emptyStateEmition", onClickValue);
};
</script>

<template>
  <div
    class="sk-empty-state"
    :class="{ 'sk-show': showEmptyState }"
    :id="id"
  >
    <div class="sk-empty-inner">

      <!-- Empty state media elements can be placed here -->
      <img class="sk-image" :src="emptyStateImage" v-if="emptyStateImage" />

      <img class="sk-image" v-if="imgUrl" :src="imgUrl" />

      <Skicon v-else :iconType="icon" v-if="icon"></Skicon>
      
      <!-- Empty state content can be placed here -->
      <b v-if="contentTitle">{{ contentTitle }}</b>
      <p v-if="content" class="sk-no-record sk-flex">{{ content }}</p>

      <!-- Empty state action items can be placed here -->
      <div class="sk-button-group" v-if="emptyStateButton != undefined">
        <Skbutton
          v-for="btn in emptyStateButton"
          :class="btn.buttonStyle"
          :buttonText="btn.actionlabel"
          @click="onClickEmptyState(btn)"
        ></Skbutton>
      </div>
    </div>
    <!-- Empty State inner :: END -->
  </div>

</template>
