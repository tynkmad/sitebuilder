<script lang="ts">
export default {
    name: "SkMultiSelect",
    components: { Skicon }
};
</script>

<script setup lang="ts">
// import { onClickOutside } from "@vueuse/core";
import { onMounted, reactive, ref } from "vue";
import { useOnClickOutside } from "./onClickOutside";
import { IListItem } from "./skglobaltypes";
import Skicon from "./skicon.vue";


// #region DATA
interface Props {
    listItems: Array<IListItem>,
    placeHolder?: string,
    name?: string
}

interface ISkTextFieldReactiveData {
    showDropDown: boolean,
    selectedValues: Array<IListItem>
}

let prop = defineProps<Props>();

let defaults: ISkTextFieldReactiveData = {
    showDropDown: false,
    selectedValues: []
}

let reactiveData = reactive(defaults);

const emit = defineEmits(["onChange", "onShow"]);

defineExpose({
    prop,
    hide,
    resetValue,
    getSelectedValues,
    setSelectedValues
})
// #endregion DATA

// #region HOOKS
const skMultiSelectRef = ref<HTMLElement | null>(null)
onMounted(() => {
    useOnClickOutside(skMultiSelectRef, () => {
        if (reactiveData.showDropDown) hide();
    });
})
// #endregion HOOKS

// #region METHOD

function hide() {
    reactiveData.showDropDown = false;
}

function getSelectedValues() {
    return reactiveData.selectedValues;
}

function setSelectedValues(selectedValues: Array<IListItem>) {
    reactiveData.selectedValues = selectedValues;
}

function resetValue() {
    prop.listItems.forEach(x => x.isSelected = false);
}

function toggleDropdown() {
    reactiveData.showDropDown = !reactiveData.showDropDown;

    if (reactiveData.showDropDown) emit("onShow", prop.name);
}

function onItemSelect(item: IListItem) {
    emit("onChange", item);
}

// #endregion METHOD


</script>
<template>
    <div ref="skMultiSelectRef" class="sk-text-select sk-small">
        <div class="sk-event-group" @click="toggleDropdown()">
            <div class="sk-selected-text">
                {{ !placeHolder && listItems.length > 0 ? listItems[0].value : placeHolder }}
            </div>
            <Skicon icon-type="expand_more"></Skicon>
        </div>
        <div class="sk-helper-line">
            <span class="sk-error-text">Error text</span>
            <span class="sk-helper-text">Helper text</span>
        </div>
        <div class="sk-overflow-list" :class="{ 'sk-show': reactiveData.showDropDown }">
            <ul>
                <li v-for="item in listItems">
                    <div class="sk-checkbox">
                        <input v-model="item.isSelected" class="sk-check-input" @change="onItemSelect(item)"
                            :name="`checkbox_${item.key}_${item.value}`" :id="`checkbox_${item.key}_${item.value}`"
                            type="checkbox">
                        <label class="sk-check-label" :for="`checkbox_${item.key}_${item.value}`">{{ item.value
                        }}</label>
                    </div>
                </li>
            </ul>
            <slot name="footer"></slot>
        </div>
    </div>
</template>

