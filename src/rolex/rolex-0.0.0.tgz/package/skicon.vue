<script lang="ts">
export default {
  name: "SkIcon",
};
</script>

<script setup lang="ts">
// define all the customizable properties
import { computed } from "vue";
interface Props {
  // Add class to the SVG icons
  iconStyle?: string;
  iconType?: string; // if iconType came it will show the metiral/PM icons
  svgIcon?: string; // if the svg icon came it will give a svg icon 
  iconSize?: string;
  iconRotate?: boolean; // Used in one place in promanage, please check to do this by using other way
  tooltip?: string;
  isColorPrimary?: boolean; // Not in use, please check and remove this props
  isMessageStatus?: boolean; // Used in promanage, please check to do this by using other way.
  verified?: boolean; // Not in use, please check and remove this props
  premiumBdage?: boolean; // Not in use, please check and remove this props
  filled?: boolean;
  tooltipTrigger?: boolean; // Not in use, please check and remove this props
  image?: string;
  clickable?: boolean;
  infoCircle?: boolean; 
  success?: boolean; // for success icon color (green)
  danger?: boolean; // for danger icon color (red)
  warning?: boolean; // for warning icon color (orange)
  skTextEnd?: boolean | true;
}

const props = defineProps<Props>();
const iconMeasure = computed(() => {
  return props.iconSize?.toLowerCase() == "xsmall"
    ? "16"
    : props.iconSize?.toLowerCase() == "small"
      ? "18"
      : props.iconSize?.toLowerCase() == "medium"
        ? "20"
        : props.iconSize?.toLowerCase() == "large"
          ? "30"
          : props.iconSize?.toLowerCase() == "exlarge"
            ? "40"
            : props.iconSize?.toLowerCase() == "" || undefined || "default"
              ? "24"
              : "24";
});

const SvgiconName = "#" + props.svgIcon;
const emit = defineEmits(["iconClicked"]);
const onClickIcon = () => {
  emit("iconClicked");
};
</script>
<template>
  <!-- Svg-icon section :: Start  -->
  <span v-if="SvgiconName != '#' && svgIcon != undefined && (iconType == '' || iconType == undefined)" @click="onClickIcon"
    class="sk-icons" :class="{ 'verified-tick': verified, 'premium-badge': premiumBdage }" :data-sk-tooltip="tooltip">
    <svg :class="iconStyle" :width="iconMeasure" :height="iconMeasure">
      <use :xlink:href="SvgiconName"></use>
    </svg>
  </span>
  <!-- Svg-icon section :: End  -->
  <!-- PM icon section :: start  -->
  <span v-if="iconType != undefined && (svgIcon == '' || svgIcon == undefined)" class="sk-icons" :data-sk-tooltip="tooltip"
    :class="{
      'sk-icon-rotate': iconRotate, // Used in one place in promanage, please check to do this by using other way.
      'sk-color-primary': isColorPrimary, // Not in use, please check and remove this props
      'small': isMessageStatus, // Used in one place in promanage, please check to do this by using other way.
      'sk-tooltip': tooltip,
      'sk-icons-filled': filled,
      'sk-tooltip-trigger': tooltipTrigger, // Not in use, please check and remove this props
      'sk-clickable': clickable,
      'sk-info-circle': infoCircle,
      'sk-success': success,
      'sk-danger': danger,
      'sk-warning': warning,
    }" @click="onClickIcon">{{ iconType }}</span>

  <span v-if="image" class="sk-icons">
    <img :src="image" />
  </span>
  <!-- PM icon section :: End  -->
</template>