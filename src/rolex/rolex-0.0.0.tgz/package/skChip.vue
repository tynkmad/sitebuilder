<script lang="ts">
export default {
    name: "SkChip",
};
</script>

<script setup lang="ts">
import SkIcon from './skicon.vue';

// define all the customizable properties
interface Props {
    chipText: string
    small?: boolean,
    filled?: boolean,
    icon?: string,
    trailingIcon?: string,
    imgUrl?: string
}

defineProps<Props>();

const emit = defineEmits(["onTrailingIconClick"])

function onTrailingIconClick() {
    emit("onTrailingIconClick");
}

</script>

<template>
    <div class="sk-chip" :class="{
        'sk-chip-filled': filled,
        'sk-small': small
    }">
        <SkIcon class="sk-icons-filled" v-if="icon" :iconType="icon" />
        <img v-if="imgUrl" :src="imgUrl">
        {{ chipText }}
        <SkIcon v-if="trailingIcon" :iconType="trailingIcon" @icon-clicked="onTrailingIconClick" />
    </div>
</template>
