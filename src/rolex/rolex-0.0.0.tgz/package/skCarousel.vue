<script setup lang="ts">
import Skicon from "./skicon.vue";
interface prop {
  noOfSlide?: number;
  enableNavDot?: boolean;
  center?: boolean;
  enableNavButton?: boolean;
  enableAutoSlide?: boolean;
  customPreviousIcon?: string;
  customNextIcon?: string;
  hidePreviousButton?:boolean;
  hideNextButton?:boolean
}

const emit = defineEmits(["movePrevious", "moveNext"]);
const MoveToPrev = () => {
  emit("movePrevious");
};
const MoveToNext = () => {
  emit("moveNext");
};
const props = defineProps<prop>();
</script>
<template>
  <div class="sk-carousel" :class="{ 'sk-carousel-center': center }" id="carousel-container-div">
    <ul class="sk-carousel-inner">
      <slot></slot>
    </ul>
    <div class="sk-carousel-dots" v-if="enableNavDot">
      <span class="sk-dot sk-active"></span>
      <span class="sk-dot" v-for="(val, index) in noOfSlide" :key="index"></span>
    </div>
    <div class="sk-carousel-nav" v-if="enableNavButton">
      <span class="sk-prev" @click="MoveToPrev" v-if="!hidePreviousButton">
        <skicon :icon-type="`${customPreviousIcon ? customPreviousIcon : 'skIconArrowPrev'}`" />
      </span>
      <span class="sk-next" @click="MoveToNext" v-if="!hideNextButton">
        <Skicon :icon-type="`${customNextIcon ? customNextIcon : 'skIconArrowNext'}`"></Skicon>
      </span>
    </div>
    <div class="sk-carousel-caption">
      <slot name="carouselCaption"></slot>
    </div>
  </div>
</template>
