<script lang="ts">
export default {
  name: "SkTextField",
};
</script>

<script setup lang="ts">
import SkIcon from "./skicon.vue";
import { reactive, watch, computed, onMounted, nextTick, ref } from "vue";
import SkButton from "./skbutton.vue";
import Skicon from "./skicon.vue";
// ##### - properties
var modalValueType: string | number;
interface Props {
  id?: string;
  inputType?: string; // Set the input type (text / email and etc.)
  placeholder?: string; // Add placeholder text
  icon?: string; // Add icon
  required?: boolean; // Set the input as required true or false
  spellCheck?: boolean; // Need to check and remove if not required
  defaultValue?: string; // TODO :: Not used need to check and remove
  error?: boolean; // Set true or false the error text
  errorText?: string; // Assign error text value
  helperText?: string; // Assign helper text value
  charCountText?: string; // Assign char count text value
  autoFocus?: boolean; // Auto focus the input by default
  
  //Floating label
  label?: string; // Add floating label
  modelValue?: typeof modalValueType;
  clearTextIcon?: boolean; // Add post fix close icon
  outlined?: boolean; // Enable floating lable option
  large?: boolean; //

  textarea?: boolean;
  small?: boolean;
  editInputField?: boolean;
  inputdisabled?: boolean;
  inputValue?: string;
  actionIcon?: string;
  svgIcon?: string;
  iconSize?: string;
  isHashNotRequired?: boolean;
  maxLength?: number;
  isDisabled?: boolean;
  iconTextIcon?: string;
  countryCode?: string;
  iconClickable?:boolean;
  // Text Area Component
  rows?: number; // Define number of rows for text area
  pasteDisable?: boolean; //Disable copy/paste option in text fields
}
const props = defineProps<Props>();
const TextInputRef = ref<any>();

const emit = defineEmits([
  "update:modelValue",
  "iconClicked",
  "onKeyupEnter",
  "onCloseInputField",
  "onKeyUp",
  "onKeyDown",
  "onClickActionIcon",
  "onPhoneprefixIconClick",
  "onFocusOut",
  "onTextBoxKeyUp"
]);

interface IReactiveData {
  value: typeof modalValueType;
  inputDisabled: boolean;
}

let dataDefaults: IReactiveData = {
  value: props.modelValue ? props.modelValue : "",
  inputDisabled: props.inputdisabled == true ? true : false,
};
let ReactiveData = reactive(dataDefaults);
watch(
  () => ReactiveData.value,
  () => {
    emit("update:modelValue", ReactiveData.value);
  }
);

watch(
  () => props.modelValue,
  () => {
    ReactiveData.value = props.modelValue ? props.modelValue : "";
    if (props.id && props.textarea) {
      (document.getElementById(props.id) as HTMLInputElement).value =
        ReactiveData.value.toString();
    }
  }
);

watch(
  () => props.inputdisabled,
  () => {
    ReactiveData.inputDisabled = props.inputdisabled ? props.inputdisabled : false;
  }
);

const setDefaultValue = (inputValue: string) => {
  ReactiveData.value = inputValue;
};
const onKeyupEnter = () => {
  emit("onKeyupEnter", ReactiveData.value);
};

const onKeyup = (event: any) => {
  emit("onKeyUp", ReactiveData.value, event);
};
const onKeydown = (event: any) => {
  emit("onKeyDown", ReactiveData.value, event);
};

const enableInputField = () => {
  ReactiveData.inputDisabled = false;
  emit("iconClicked");
};
const autoFocus=async()=>{
  await nextTick(()=>{
    setTimeout(()=>{
      TextInputRef.value.focus();
    },300)
  });
}
function setValue(e:any) {
  emit("onTextBoxKeyUp",e.target.value);
  if (props.id)
    ReactiveData.value = (
      document.getElementById(props.id) as HTMLInputElement
    ).value;
}

function getValue() {
  return typeof ReactiveData.value == "string"
    ? ReactiveData.value
    : parseInt(ReactiveData.value.toString());
}

const clearValue = () => {
  ReactiveData.value = "";
  if (props.id && props.textarea)
    (document.getElementById(props.id) as HTMLInputElement).value = "";
};

const onClose = () => {
  emit("onCloseInputField");
};

const onClickActionIcon = () => {
  emit("onClickActionIcon");
};

const onPhoneprefixIconClick = () => {
  emit("onPhoneprefixIconClick");
};

const resetData = (isDisabled: boolean = true) => {
  ReactiveData.inputDisabled = isDisabled;
};
const onFocusOut = (event: any) => {
  emit("onFocusOut",event);
}
defineExpose({
  clearValue,
  setDefaultValue,
  resetData,
  getValue,
  autoFocus
});
</script>

<template>
  <div
    class="sk-text-field"
    :class="{
      'sk-outlined-input': outlined || ReactiveData.value,
      'sk-large': large,
      'sk-small': small,
      'sk-leading-text': icon == 'phoneprefix',
      // 'sk-leading-icon sk-trailing-icon': icon == 'search',
      // 'sk-leading-icon': svgIcon == 'skIconSearch',
      'sk-disabled': ReactiveData.inputDisabled,
      'sk-error': error,
    }"
  >
    <span @click="onPhoneprefixIconClick" v-if="icon == 'phoneprefix'" class="sk-text">
      <span class="sk-text-inner">
        {{ countryCode || '+91' }}
      <skIcon v-if="iconTextIcon && iconTextIcon != ''" :iconType="iconTextIcon"/>
      </span> 
    </span>
    <!-- <span class="sk-icons"></span> -->
    <Skicon
      @iconClicked="onClose"
      v-if="icon !== 'phoneprefix' ? icon : ''"
      :icon-type="icon"
      :iconSize="iconSize"
      :clickable="iconClickable"
    />

    <textarea
      class="sk-textarea"
      :id="id"
      v-model="ReactiveData.value"
      @keyup="setValue"
      v-if="textarea"
      rows="4"
      cols="50"
      :required="required"
      :placeholder="placeholder"
      :maxlength="maxLength"
      :onpaste="!pasteDisable ? 'return true;' : 'return false;'"
    />
    <input
      v-else
      class="sk-input"
      :id="id"
      ref="TextInputRef"
      :type="inputType"
      :required="required"
      :placeholder="placeholder"
      :disabled="isDisabled"
      v-model="ReactiveData.value"
      v-on:keyup.enter="onKeyupEnter"
      v-on:keyup="onKeyup($event)"
      v-on:keydown="onKeydown($event)"
      v-on:blur="onFocusOut($event)"
      :onpaste="!pasteDisable ? 'return true;' : 'return false;'"
    />

    <label v-if="label" class="sk-floating-label">
      {{ label }}
      <span
        class="sk-required"
        :class="{
          'sk-hide': isHashNotRequired,
        }"
        >*</span
      >
    </label>
    <div class="sk-helper-line">
      <span v-if="error" class="sk-error-text sk-show">{{ errorText }}</span>
    <span v-if="helperText && !error" class="sk-helper-text sk-show">{{
      helperText
    }}</span>
    <span v-if="charCountText" class="sk-char-counter sk-show">{{ charCountText }}</span>
    </div>
    
    <SkIcon
      @iconClicked="clearValue"
      v-if="clearTextIcon && ReactiveData.value"
      icon-type="clear"
    />
    <!-- Trailing action button -->
    <SkButton
      v-if="!editInputField && actionIcon"
      :icon="actionIcon"
      @click="onClickActionIcon"
    />
    <!-- Trailing action button - Edit button is enabled even the text field is disabled -->
    <SkButton
      v-if="editInputField"
      class="sk-button-edit"
      :icon="actionIcon"
      @click="enableInputField"
    />
  </div>
</template>

<style></style>
