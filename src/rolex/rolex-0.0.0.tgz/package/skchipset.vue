<script lang="ts">
export default {
  name: "SkChipSet",
};
</script>
<script setup lang="ts">
import skIcon from "./skicon.vue";
import { chipProps, listItemType } from "./skglobaltypes";
import SkButton from "./skbutton.vue";

interface Props {
  chipStyle?: string;
  scrollable?: boolean;
  filled?: boolean;
  disableSelect?: boolean;
  chips: Array<chipProps>;
}
const props = defineProps<Props>();

const emit = defineEmits(["onChipClick"]);

function onChipClick(index: number) {
  let chip: chipProps;
  chip = props.chips[index];
  if (!props.disableSelect) {
    // let key: string | null = (evt.currentTarget as HTMLElement).getAttribute("key");
    //if (key != null) {
    if (index >= 0) {
      chip.selected = !chip.selected; // todo - this should be a style of chipset ?
      emit("onChipClick", chip);
    }
  } else {
    emit("onChipClick", chip);
  }
}
function onCloseClick(index: number) {
  if (!props.disableSelect) {
    let chip: chipProps;
    chip = props.chips[index];
    if (index >= 0) {
      chip.selected = !chip.selected; // todo - this should be a style of chipset ?
      emit("onChipClick", chip);
    }
  }
}
</script>

<template>
  <div class="sk-chipset" :class="{'sk-scrollable': scrollable}">
    <div
      @click="onChipClick(index)"
      class="sk-chip"
      :class="{
        'sk-chip-selected': chip.selected,
        'sk-chip-removable': chip.removable,
        'sk-chip-filled': filled || chip.filled,
        'sk-small': chip.small,
        'sk-xsmall': chip.xsmall,
        'sk-disabled': chip.disabled,
      }"
      v-for="[index, chip] in chips.entries()"
    >
      <skIcon v-if="chip.selected" iconType="check" />
      <img v-if="chip.imgUrl" :src="chip.imgUrl">
      <skIcon class="sk-icons-filled" v-if="chip.icon" :iconType="chip.icon" />
      {{ chip.withCount ? "" : chip.chipMessage }}
      <SkButton v-if="chip.removable" icon="close" />
      <span v-if="chip.withCount">{{ chip.chipMessage }}</span>
      <span v-if="chip.withCount" class="count">{{ chip.chipCount }}</span>
    </div>
  </div>
</template>

<style></style>
