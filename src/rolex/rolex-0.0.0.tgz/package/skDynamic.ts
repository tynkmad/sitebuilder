import { Component, defineAsyncComponent, defineComponent, shallowRef } from "vue";

const DynamicComponent = shallowRef();
interface DynamicImport {
  componentName: string;
  componentRelativePath: string;
  MountingState?: boolean;
  Component?:undefined;
}

const PathConvertor = (RelativePath: string) => {
  let absolutePath = "";
  RelativePath.includes("SKXF/vue/skxfvue/src");
  {
    absolutePath = RelativePath.replace("SKXF/vue/skxfvue/src", "..");
  }

  return absolutePath;
};

export const DynamicImport = (VueElemet: DynamicImport) => {
  let ComponentAbsolutePath = PathConvertor(VueElemet.componentRelativePath);

  if (VueElemet.MountingState) {
    let Component = defineComponent({
      name: VueElemet.componentName,
      components: {
        VueComponent: defineAsyncComponent(
          () => import(/* @vite-ignore */ ComponentAbsolutePath)
        )
      }
    });
    DynamicComponent.value = Component.components?.VueComponent as Component;
  }else{
    DynamicComponent.value=''
  }
  return DynamicComponent.value
};