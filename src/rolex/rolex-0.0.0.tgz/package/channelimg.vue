<script lang="ts">
export default {
  name: "ChannelImg",
};
</script>

<script setup lang="ts">
import { computed, ref, watch } from "vue";
import { MediumType } from "./SkTypes";
// define all the customizable properties
var channelType: string | number;
interface Props {
  channel?: typeof channelType;
}
const props = defineProps<Props>();
const channelImg = computed(() => {
  let channelImgStr = "https://lscdn.blob.core.windows.net/content/promanage/";

  switch (props.channel?.toString().toLowerCase()) {
    case "0":
    case "sulekha":
    case "":
    case null:
    case undefined:
    case MediumType.Sulekha.toString():
      channelImgStr = "https://lscdn.blob.core.windows.net/content/images/sulekha-emblem.png";
      break;
    case "1":
    case "google":
    case MediumType.Google.toString():
      channelImgStr = channelImgStr + "google-logo.svg";
      break;
    case "2":
    case "whatsapp":
      channelImgStr = channelImgStr + "whatsapp.svg";
      break;
    case "3":
    case "bing":
    case MediumType.Bing.toString():
      channelImgStr = channelImgStr + "bing.svg";
      break;
    case "4":
    case "facebook":
    case MediumType.Facebook.toString():
      channelImgStr = "https://usimg.sulekha.io/cdn/others/promotions/facebook_2025-04-23-06-23-06-466.png";
      break;
    case "5":
    case "bvn_call":
    case "bvncall":
      channelImgStr = channelImgStr + "bvn-call.svg";
      break;
    case "6":
    case "microsite":
    case MediumType.Microsite.toString():
      channelImgStr = channelImgStr + "microsite-logo.svg";
      break;
    case "7":
    case "promanageapp":
    case MediumType.PromanageApp.toString():
      channelImgStr = channelImgStr + "pm-icon.svg";
      break;
    case "8":
    case "playstore":
    case MediumType.PlayStore.toString():
      channelImgStr = channelImgStr + "playstore-logo.svg";
      break;
    case "9":
    case "hotfrog":
    case MediumType.Hotfrog.toString():
      channelImgStr = channelImgStr + "hotfrog.svg";
      break;
    case "10":
    case "mapmyindia":
    case MediumType.MapmyIndia.toString():
      channelImgStr = channelImgStr + "map-my-india-logo.svg";
      break;
    case "globe":
      channelImgStr = channelImgStr + "globe-logo.svg";
      break;
    case "youtube":
      channelImgStr = "https://usimg.sulekha.io/cdn/others/promotions/youwhite_2026-02-10-05-11-57-444.png";
      break;
    case "flickr":
      channelImgStr = channelImgStr + "flickr-logo.svg";
      break;
    case "reddit":
      channelImgStr = channelImgStr + "reddit-logo.svg";
      break;
    case "twitter":
      channelImgStr = "https://usimg.sulekha.io/cdn/others/promotions/twitter_2025-04-23-06-02-17-042.png";
      break;
    case "dailymotion":
      channelImgStr = channelImgStr + "dailymotion-logo.svg";
      break;
    case "vimeo":
      channelImgStr = channelImgStr + "vimeo-logo.svg";
      break;
    case "vkontakte":
      channelImgStr = channelImgStr + "vkontakte-logo.svg";
      break;
    case "external":
      channelImgStr = channelImgStr + "external-source.svg";
      break;
    case "merlin":
      channelImgStr = channelImgStr + "merlin-icon.svg";
      break;
    case "website":
    case "widget":
    case "sulekhawidget":
    case "promanagewidget":
    case "micrositewidget":
      channelImgStr = channelImgStr + "website-logo.svg";
      break;
    case "promanage":
      channelImgStr = channelImgStr + "pm-icon.svg";
      break;
  }
  return channelImgStr;
});
</script>

<template>
  <img :src="channelImg" />
</template>
