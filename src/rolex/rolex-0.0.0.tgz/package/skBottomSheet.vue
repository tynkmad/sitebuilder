<script setup lang="ts">
import { computed } from "@vue/reactivity";
import { ref } from "vue";

interface prop {
  showBottomSheet: boolean;
}
const props = defineProps<prop>();
const HtmlBody = ref(document.getElementsByTagName("body")[0]);
const showHidebottom=computed(()=>{
    if (props.showBottomSheet) {
    HtmlBody.value.setAttribute("class", "sk-disabled-scroll");
  } else if (
    props.showBottomSheet == false ||
    props.showBottomSheet == undefined
  ) {
    HtmlBody.value.classList.remove("sk-disabled-scroll");
  }
  return props.showBottomSheet;
});
</script>
<template>
  <div
    :class="{
      'sk-bottomsheet sk-show': showHidebottom,
      'sk-bottomsheet sk-hide': !showHidebottom,
    }"
  >
    <div class="sk-bottomsheet-container">
      <div class="sk-bottomsheet-inner">
        <div class="sk-bottomsheet-header">
          <slot name="bottomSheetsHeader"></slot>
        </div>
        <div class="sk-bottomsheet-body">
          <slot name="bottomSheetsBody"></slot>
        </div>
      </div>
    </div>
    <div class="sk-backdrop"></div>
  </div>
</template>
