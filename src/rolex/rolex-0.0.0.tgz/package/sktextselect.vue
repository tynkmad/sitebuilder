
<!-- Please refer this file skdropdown.vue -->
<script lang="ts">
export default {
  name: "SkTextSelect",
};
</script>

<script setup lang="ts">
import { onMounted, reactive, ref } from "vue";
import { useOnClickOutside } from "./onClickOutside";
import { IListItem } from "./skglobaltypes";


// #region DATA
interface Props {
  listItems: Array<IListItem>,
  placeHolder?: string,
  name?: string,
  large?:boolean,
  floatingLabel?:boolean,
  isMandatory?: boolean
}

interface ISkTextFieldReactiveData {
  showDropDown: boolean,
  selectedValue: IListItem
}

let prop = defineProps<Props>();

let defaults: ISkTextFieldReactiveData = {
  showDropDown: false,
  selectedValue: {
    key: 0,
    value: prop.placeHolder,
    isSelected: true
  }
}

let reactiveData = reactive(defaults);

const emit = defineEmits(["onChange", "onShow"]);

defineExpose({
  prop,
  hide,
  resetValue,
  getSelectedValue,
  setSelectedValue
})
// #endregion DATA

// #region HOOKS
const sktextselectRef = ref<HTMLElement | null>(null)
onMounted(() => {
  useOnClickOutside(sktextselectRef, () => {
    if (reactiveData.showDropDown) hide();
  });
})
// #endregion HOOKS

// #region METHOD

function hide() {
  reactiveData.showDropDown = false;
}

function getSelectedValue() {
  return reactiveData.selectedValue;
}

function setSelectedValue(selectedValue: IListItem) {
  reactiveData.selectedValue = selectedValue;
}

function resetValue() {
  reactiveData.selectedValue = {
    key: 0,
    value: prop.placeHolder,
    isSelected: true
  };
}

function toggleDropdown() {
  reactiveData.showDropDown = !reactiveData.showDropDown;

  if (reactiveData.showDropDown) emit("onShow", prop.name);
}

function onItemSelect(item: IListItem) {
  prop.listItems.forEach(x => x.isSelected = false);
  item.isSelected = true;
  reactiveData.selectedValue = item;
  emit("onChange", item);
  toggleDropdown();
}
// #endregion METHOD

</script>
<template>
  <div ref="sktextselectRef" class="sk-text-select" :class="{
    'sk-valid': reactiveData.selectedValue.value != ''
  }">
    <div class="sk-event-group" @click="toggleDropdown()">
      <div class="sk-selected-text">
        {{ reactiveData.selectedValue.value }}
      </div>
      <label class="sk-floating-label" v-if="floatingLabel"
          >{{ placeHolder
          }}<span class="required" v-if="isMandatory">*</span></label
        >
      <span class="sk-icons">expand_more</span>
    </div>
    <div class="sk-helper-line">
      <span class="sk-error-text">Error text</span>
      <span class="sk-helper-text">Helper text</span>
    </div>
    <ul class="sk-overflow-list" :class="{ 'sk-show': reactiveData.showDropDown }">
      <li v-for="item in listItems" :class="{ 'sk-selected': item.isSelected }" :key="item.key"
        @click="onItemSelect(item)">
        {{ item.value }}
      </li>
    </ul>
  </div>
</template>


  <!-- <div class=" sk-valid" id="singleSelect">
            <div class="sk-event-group">
                <div class="sk-selected-text">All Tags</div>
                <span class="sk-icons">expand_more</span>
            </div>
            <div class="sk-helper-line">
                <span class="sk-error-text">Error text</span>
                <span class="sk-helper-text">Helper text</span>
            </div>
            <ul class="sk-overflow-list">
                <li class="">All</li>
                <li class="">Happy</li>
                <li class="sk-selected">Hot Prospect</li>
                <li>Priority</li>
                <li>Upset</li>
            </ul>
          </div> -->

  <!-- <div class="sk-text-select">
    <div class="sk-event-group">
      <div class="sk-selected-text" @click="toggleDropdown">
        {{ modelValue ? modelValue : placeHolder }}
      </div>
      <span class="sk-icons">expand_more</span>
    </div>
    <div class="sk-helper-line">
      <span class="sk-error-text">Error text</span>
      <span class="sk-helper-text">Helper text</span>
    </div>
    <ul class="sk-overflow-list" ref="skListOptions">
      <li v-for="item in searchItems" :key="item" @click="onItemSelect">
        {{ item }}
      </li>
    </ul>
    <div class="sk-text-field">
      <input
        ref="txtInput"
        class="sk-input"
        type="text"
        :placeholder="placeHolder"
        required
        @focus="toggleDropdown"
        :value="modelValue"
        @input="
                    $emit('update:modelValue', $event.target != null ? ($event.target as HTMLInputElement).value : '')
                "
      />

      <div class="sk-overflow-menu">
        <Skbutton
          class="filter-dropdown"
          round
          no-shadow
          icon="expand_more"
          @click="toggleDropdown"
        />

        <ul class="sk-overflow-list" ref="skListOptions" @click="onItemSelect">
          <li v-for="item in searchItems" :key="item">
            {{ item }}
          </li>
        </ul>
      </div>
    </div>
  </div> -->
