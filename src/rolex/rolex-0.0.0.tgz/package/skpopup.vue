<script lang="ts">
export default {
  components: { skicon },
  name: "SkPopup",
};
</script>
<script setup lang="ts">
import { ISkButton, skActionItem } from "./skglobaltypes";
import SkButton from "./skbutton.vue";
import { onMounted, ref } from "vue";
import Skbutton from "./skbutton.vue";
import { useOnClickOutside } from "./onClickOutside";
import skicon from './skicon.vue';

interface Props {
  popupActionItems: skActionItem[]; //  list of menu items on the right.  first 2 should be shown as icons rest inside a tripple dot menu
  isEndPosition?: boolean;
  triggerButton?: ISkButton;
  hasCustomTriggerElement?: boolean;
  showOnlyIcon?: boolean;
}

const actionItems: Array<skActionItem> = [
  { itemKey: "1", actionIcon: "power_rounded", actionlabel: "Disconnect" },
];

const toggleShowHide = ref(false);
const props = defineProps<Props>();
const emit = defineEmits(["overflowMenuClick"]);

const actionItemClick = (Key: string) => {
  emit("overflowMenuClick", Key);
  toggleShowHide.value = !toggleShowHide;
};

const overflowList = ref<HTMLElement | null>(null);
onMounted(() => {
  useOnClickOutside(overflowList, () => {
    toggleShowHide.value = false;
  });
});
</script>
<template>
  <div
    class="sk-overflow-menu"
    :class="{
      'sk-text-end': isEndPosition,
    }"
  >
    <div class="sk-menu-trigger">
      <template v-if="hasCustomTriggerElement">
        <slot name="trigger-content"></slot>
      </template>
      <Skbutton
        v-else
        :outline="triggerButton?.outline"
        :round="triggerButton?.round"
        :rounded="triggerButton?.rounded"
        :noShadow="triggerButton?.noShadow"
        :badge-type="triggerButton?.badgeType"
        :icon="triggerButton?.icon"
        :small="triggerButton?.small"
        :linkText="triggerButton?.linkText"
        @click="toggleShowHide = !toggleShowHide"
      >
      </Skbutton>
    </div>

    <div
      class="sk-overflow-list"
      :class="{ 'sk-show': toggleShowHide, 'sk-hide': !toggleShowHide }"
    >
      <ul ref="overflowList">
        <li
          v-for="item in popupActionItems"
          :key="item.itemKey"
          :class="{'selected-list': item.isActive}"
          @click="actionItemClick(item.itemKey)"
        >
          <!-- if action items  -->
          <SkButton rounded noShadow small v-if="item.actionIcon && !showOnlyIcon" :icon="item.actionIcon" :use-svg="false" />
          <skicon v-if="showOnlyIcon" :icon-type="item.actionIcon" :isColorPrimary="item.isColorPrimary"/>
          {{ item.actionlabel }}
          <!-- else just display options -->
        </li>
      </ul>
    </div>
  </div>
</template>
