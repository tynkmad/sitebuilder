<script setup lang="ts">
import skIcon from './skicon.vue';

interface expandPanelInterface {
  title: string;
  value: string[];
  isActive: boolean;
}

interface prop {
  ExpansionpanelData: expandPanelInterface[]
  useSvg?:boolean;
}

const props = defineProps<prop>();

const expandPanel = (arrayValue: expandPanelInterface) => {
  arrayValue.isActive = !arrayValue.isActive
}
</script>
<template>
  <div class="sk-expansion-panels">
    <div v-for="(arrayValue, index, obj) in ExpansionpanelData" :key="index"
      :class="arrayValue.isActive ? 'sk-expansion-inner sk-active' : 'sk-expansion-inner'">
      <div class="sk-expansion-header">
        <div class="sk-expansion-action" @click="expandPanel(arrayValue)">
        {{arrayValue.title}}
        <skIcon   :svgIcon="useSvg?'skIconDownChevron':''"
                 :iconType="useSvg?'':'expand_more'"
         iconSize="default" >
          
        </skIcon>
      </div>
      </div>
      <div class="sk-expansion-content">
        <ul>
          <li v-for="value in arrayValue.value">
            {{ value }}
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
