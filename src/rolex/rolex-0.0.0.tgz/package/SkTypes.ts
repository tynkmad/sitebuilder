enum MediumType {
    All = -1,
    Google = 83,
    Facebook = 161,
    PromanageApp = 82,
    Sulekha = 108,
    Bing = 107,
    PlayStore = 187,
    Microsite = 207,
    Hotfrog = 214,
    MapmyIndia = 247
}

enum ToolTipDirection {
    Right = 'right',
    Left = 'left',
    Top = 'top',
    Bottom = 'bottom',
}


export {
    MediumType,
    ToolTipDirection
}
