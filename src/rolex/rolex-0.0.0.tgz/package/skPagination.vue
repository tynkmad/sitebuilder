<script setup lang="ts">
import { onMounted, ref, watch } from "vue";
import Skicon from "./skicon.vue";

interface prop {
  pageCountInRow: number;
  totalNumberOfPages: number;
  useSvg?: boolean;
}
const props = defineProps<prop>();

interface paginationType {
  pageNumber: number;
  isActive: boolean;
}

const currentPage = ref<number>(1);
const startPage = ref<number>(1);
const endPage = ref<number>(props.pageCountInRow);
const isLeftMoveEnable = ref(false);
const isRightMoveEnable = ref(true);

const preClick = () => {
  if (startPage.value > 1) {
    currentPage.value -= 1;
    startPage.value -= 1;
    endPage.value -= 1;
    isRightMoveEnable.value = true;
  }
  isLeftMoveEnable.value = currentPage.value != 1 ? true : false;
  init(startPage.value);
};

const nextClick = () => {
  if (endPage.value < 10) {
    currentPage.value += 1;
    startPage.value += 1;
    endPage.value += 1;
    isLeftMoveEnable.value = true;
  }
  isRightMoveEnable.value = currentPage.value != props.totalNumberOfPages ? true : false;
  init(startPage.value);
};

const shownPageList = ref<paginationType[]>([]);

onMounted(() => {
  init(startPage.value);
});

const init = (page: number) => {
  shownPageList.value = [];
  startPage.value = page;
  for (let i = startPage.value; i <= endPage.value; i++) {
    shownPageList.value.push({
      isActive: i === currentPage.value,
      pageNumber: i,
    });
  }
};

watch(currentPage, () => {
  emit("paginationEmition", currentPage.value);
});
const emit = defineEmits(["paginationEmition"]);
const onClickToPage = (pageNo: number) => {
  currentPage.value = pageNo;
  isRightMoveEnable.value = currentPage.value != props.totalNumberOfPages ? true : false;
  isLeftMoveEnable.value = currentPage.value > 1 ? true : false;
  init(startPage.value);
};
</script>
<template>
  <nav class="sk-pagination">
    <ul>
      <li @click="preClick" v-if="isLeftMoveEnable">
        <a>
          <Skicon icon-type="chevron_left"></Skicon>
        </a>
        <span class="sk-ripple-container"></span>
      </li>
      <li
        v-for="(page, index) in shownPageList"
        :key="index"
        :class="{ 'sk-active': page.isActive }"
        @click="onClickToPage(page.pageNumber)"
      >
        <a>{{ page.pageNumber }}</a>
        <span class="sk-ripple-container"></span>
      </li>

      <li @click="nextClick" v-if="isRightMoveEnable">
        <a>
          <Skicon
            :iconType="useSvg ? '' : 'chevron_right'"
            :svgIcon="useSvg ? 'chevron_right' : ''"
          ></Skicon>
        </a>
        <span class="sk-ripple-container"></span>
      </li>
    </ul>
  </nav>
</template>
