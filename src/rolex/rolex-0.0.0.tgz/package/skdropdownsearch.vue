<script lang="ts">
export default {
  name: "SkDropdownSearch",
};
</script>

<script setup lang="ts">
import SkButton from "./skbutton.vue";
import { ref, computed, watch, reactive } from "vue";
import { HtmlItemSizeOptions } from "./skglobaltypes";

// define all the customizable properties
interface Props {
  placeHolder?: string;
  searchItems: any;
  modelValue?: string;
  actionicon?: string;
  showSearchItems?: boolean;
  hideSearchItems?:boolean;
  notRequired?: boolean;
  floatingLabel?: string;
  size?: HtmlItemSizeOptions;
  disabled?: boolean;
  hasSubText?: boolean;
  isKeyValue?: boolean;
  error?: boolean;
  errorText?: string;
  multiSearch?:boolean
}

var showSearchResults = ref(false);
// const {iconType='',useSvg=false,badge=false,pageName=''} = defineProps<Props>();
const props = defineProps<Props>();

interface IReactiveData {
  inputDisabled: boolean;
}

let dataDefaults: IReactiveData = {
  inputDisabled: props.actionicon == "edit" ? true : false,
};
let ReactiveData = reactive(dataDefaults);
const skListOptions = ref<HTMLElement>();

const emit = defineEmits(["update:modelValue", "onKeyUp", "actionIconClicked", "onItemSelect", "handleEnterKey"
]);

function onClickActionIcon() {
  if (props.actionicon == "edit") {
    ReactiveData.inputDisabled = false;
  }
  emit("actionIconClicked");
}

const txtInput = ref<HTMLInputElement | null>(null);
function onItemSelect(evt: Event) {
  if (txtInput.value != null) {
    txtInput.value.value = (evt.target as HTMLElement).innerText;
    emit("update:modelValue", txtInput.value.value);
    emit("onItemSelect", txtInput.value.value);
  }
  if(!props.multiSearch)showSearchResults.value = false;
  // onClickActionIcon();
}

function onKeyValueItemSelect(keyValue: any) {
  if (txtInput.value != null) {
    txtInput.value.value = keyValue.value;
    emit("update:modelValue", keyValue);
    emit("onItemSelect", keyValue);
  }
  showSearchResults.value = false;
  // onClickActionIcon();
}

function onItemSelectWithSubText(value: any) {
  if (value) {
    emit("update:modelValue", value);
    emit("onItemSelect", value);
  }
  showSearchResults.value = false;
}

const onChangeInputData = (evt: any) => {
  emit("onKeyUp", evt.target.value);
};

const handleEnterKey = (evt: any) => {
  emit("handleEnterKey", evt.target.value);
};

// ### for v-model support

const value = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit("update:modelValue", value);
  },
});
watch(
  () => {
    if (props.searchItems?.length) {
      showSearchResults.value = true;
    } else {
      showSearchResults.value = false;
    }
  },
  () => { }
);
function setDisabled(disabled: boolean) {
  ReactiveData.inputDisabled = disabled;
}

const resetValues = () => {
  if (props.actionicon == "edit") {
    ReactiveData.inputDisabled = true;
  } else {
    ReactiveData.inputDisabled = false;
  }
};

const clearInput = () =>{
  if(txtInput.value != null)
    txtInput.value.value= '';
}

defineExpose({
  resetValues,
  setDisabled,
  clearInput
});
</script>

<template>
  <div class="sk-text-field sk-outlined-input sk-trailing-icon" :class="{
    'sk-disabled': ReactiveData.inputDisabled || disabled,
    'sk-small': size == HtmlItemSizeOptions.Small,
    'sk-large': size == HtmlItemSizeOptions.Large,
    'sk-xlarge': size == HtmlItemSizeOptions.ExtraLarge,
  }">
    <input ref="txtInput" class="sk-input" type="text" :placeholder="placeHolder" @focus="" :value="modelValue"
      @keyup="onChangeInputData($event)" @keyup.enter="handleEnterKey($event)" @input="
        $emit(
          'update:modelValue',
          $event.target != null ? ($event.target as HTMLInputElement).value : ''
        )
        " required />

    <label v-if=floatingLabel class="sk-floating-label">{{ floatingLabel }}
      <span v-if="!notRequired" class="sk-required">*</span></label>
    <div v-if="error" class="sk-helper-line">
      <span class="sk-error-text sk-show">{{ errorText }}</span>
    </div>

    <SkButton
      v-if="actionicon"
      linkText
      :icon="actionicon"
      @click="onClickActionIcon"
      class="sk-button-edit"
    />
    <div class="sk-overflow-menu" :class="{ 'sk-hide': !showSearchResults }" v-if="!hideSearchItems">
      <ul
        class="sk-overflow-list"
        :class="{ 'sk-show': showSearchResults, 'sk-hide': !showSearchResults }"
        ref="skListOptions"
      >
        <template v-if="!hasSubText">
          <li v-for="(item, index) in searchItems" :key="index" @click="($event) => {
            if (isKeyValue)
              onKeyValueItemSelect(item);
            else
              onItemSelect($event)
          }">
            {{ isKeyValue ? item.value : item }}
          </li>
        </template>
        <template v-if="hasSubText">
          <li v-for="(item, index) in searchItems" :key="index" @click="onItemSelectWithSubText(item.text)">
            {{ item.text }}
            <span>{{ item.subText }}</span>
          </li>
        </template>
      </ul>
    </div>
  </div>
</template>
