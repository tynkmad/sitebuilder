<script lang="ts">
export default {
    name: "SkTableData",
    components: { Skchipset, Skcheckbox, SkButtonGroup, SkIcon, SkChip, Skbutton, SkToolTip, Skpopup }
};
</script>

<script setup lang="ts">
// import { getStarClass } from '../PM/services/utilFunctions';
import { TableDataTypes, ITableData,HtmlItemSizeOptions } from './skglobaltypes';
import Channelimg from './channelimg.vue';
import { getStarClass } from './utilFunctions';
import { useRouter } from "vue-router";
import Skchipset from './skchipset.vue';
import Skcheckbox from './skcheckbox.vue';
import SkButtonGroup from './skButtonGroup.vue';
import SkIcon from './skicon.vue';
import SkChip from './skChip.vue';
import Skbutton from './skbutton.vue';
import SkToolTip from "./skToolTip.vue";
import { ToolTipDirection } from './SkTypes';
import Skpopup from './skpopup.vue';
import SkLoader from './skLoader.vue';
import SkSwitch from "./skswitch.vue";
import Skdropdown from "./skdropdown.vue";

interface Props {
    prop: ITableData
}

defineProps<Props>();
const router = useRouter();

const navigateTo = (path?: string, queryParams?: any) => {
    if (path) router.push({ name: path, query: queryParams });
};

function onSentimentMouseAction(event: any, sentimentBreakUp: { positive: number, negative: number, neutral: number }) {
    let x = event.clientX;
    let y = event.clientY;
    // var screenHieght = window.innerHeight; 

    let div = document.getElementById("myDiv") as HTMLElement;

    div.style.display = "block";
    div.style.position = "absolute";
    div.style.background = "var(--color-white)";
    div.style.width = "15rem";
    div.style.boxShadow = "var(--box-shadow-4)";
    div.style.padding = "var(--font-size-base)";
    div.style.left = x + "px";
    div.style.top = y + "px";

    let positive = document.getElementById("sentiment-positive");
    let negative = document.getElementById("sentiment-negative");
    let neutral = document.getElementById("sentiment-neutral");
    if (positive) positive.innerHTML = sentimentBreakUp.positive.toString();
    if (negative) negative.innerHTML = sentimentBreakUp.negative.toString();
    if (neutral) neutral.innerHTML = sentimentBreakUp.neutral.toString();

    div.classList.remove("sk-hide");
}

function onSentimentMouseLeave() {
    if (window.innerWidth > 992) {
        var div = document.getElementById("myDiv") as HTMLElement;
        div.classList.add("sk-hide");
    }
}

</script>

<!-- Note: Table Data is different for each tables so user can add on different TableDataTypes. Will render only one <td> -->
<template>
    <td v-if="prop.type" :class="[prop.hide ? 'sk-hide' : '', prop.class]">

        <small v-if="prop.type == TableDataTypes.Growth" :class="prop.data >= 0 ? 'sk-value-up' : 'sk-value-down'">
            <span class="sk-icons">{{ prop.data >= 0 ? 'arrow_upward' : 'arrow_downward' }}</span>
            {{ Math.abs(prop.data) }}%
        </small>

        <div v-if="prop.type == TableDataTypes.Sentiment" class="business-data">
            <template v-if="prop.data.isBusinessCol">
                <router-link :to="{ name: prop.data.profileLink, query: prop.data.linkQueryParams }">
                    {{ prop.data.businessName }}
                </router-link>
                <!-- <p>{{ prop.data.businessName }}</p> -->
                <div class="sk-flex-row">
                    <div>
                        <b>Reviews:</b> {{ prop.data.reviewCount }}
                    </div>
                    <div class="business-information">
                        <b>Overall: <span :class="prop.data.sentimentColor"
                                @click="onSentimentMouseAction($event, prop.data.sentimentBreakUp)"
                                @mouseover="onSentimentMouseAction($event, prop.data.sentimentBreakUp)"
                                @mouseleave="onSentimentMouseLeave">{{ prop.data.sentiment
                                }}</span></b>
                    </div>
                </div>
            </template>
            <template v-else>
                <div :class="prop.data.sentimentColor" @click="onSentimentMouseAction($event, prop.data.sentimentBreakUp)"
                    @mouseover="onSentimentMouseAction($event, prop.data.sentimentBreakUp)"
                    @mouseleave="onSentimentMouseLeave">{{ prop.data.sentiment }}</div>
            </template>
        </div>

        <span v-if="prop.type == TableDataTypes.StarRating" class="sk-ratings sk-small">
            <b>{{ prop.data }}</b>
            <span :class="['sk-star', getStarClass(prop.data)]"></span>
        </span>


        <router-link v-if="prop.type == TableDataTypes.Link" :title="prop.data?.toolTipText"
            :to="{ name: prop.data.btnLink, query: prop.data.linkQueryParams }">
            {{ prop.data.text }}
        </router-link>


        <span v-if="prop.type == TableDataTypes.Badge" class="sk-badge" :class="`sk-badge-${prop.data.type} ${prop.data.additionalClass}`">{{
            prop.data.value }}</span>

        <button :disabled="prop.data.disabled" v-if="prop.type == TableDataTypes.Button" class="sk-button"
            :class="prop.data.buttonClassList" @click="prop.data.action">{{ prop.data.buttonText }}</button>

        <div v-if="prop.type == TableDataTypes.PlatForms" class="social-group">
            <div class="sk-flex-row">
                <div v-for="platform in prop.data" class="sk-avatar sk-small">
                    <Channelimg :channel="platform" />
                </div>
            </div>
        </div>

        <div v-if="prop.type == TableDataTypes.BadgeWithText" class="sk-flex-row">
            <span :class="`sk-badge sk-badge-${prop.data.type}`">{{ prop.data.badgeText }}</span>
            <small class="sk-error-text">{{ prop.data.errorText }}</small>
        </div>

        <div v-if="prop.type == TableDataTypes.Paragraph">
            <p>
                {{ prop.data }}
            </p>
        </div>

        <SkChip v-if="prop.type == TableDataTypes.Chip" :chip-text="prop.data.chipText" :small="prop.data.small"
            :filled="prop.data.filled" />

        <Skcheckbox v-if="prop.type == TableDataTypes.CheckBox" :is-checkbox="true" :chkid="`tdChk_${Math.random()}`"
            :is-checked="prop.data.isChecked" @change="prop.data.action()" :disabled="prop.data.disabled" />

        <SkButtonGroup v-if="prop.type == TableDataTypes.ButtonGroup" :button-group="prop.data.buttonGroup"
            :justify-end="prop.data.justifyEnd" :over-flow-items="prop.data.overflowItems"
            :over-flow-item-action="prop.data.overflowItemAction"></SkButtonGroup>

        <div v-if="prop.type == TableDataTypes.TitleAndContent" class="sk-flex-row sk-no-wrap">
            <div class="sk-tooltip-rich sk-tooltip-top">
                <b class="sk-clickable" :class="{ 'sk-disabled': prop.data.disabled, 'sk-link': !prop.data.disabled }"
                    @click="prop.data.action()">{{ prop.data.title }}</b>
                <div v-if="prop.data.disabled" class="sk-tooltip-wrapper">
                    <div class="sk-tooltip-inner">
                        <p>You cannot access this profile until it gets verfied on Google.</p>
                    </div>
                </div>
                <p class="address">{{ prop.data.content }}</p>
                <div class="profile-score sk-flex-row">
                    <!-- <small>Profile score: <b :class="prop.data.healthColor">{{ prop.data.profileHealth }}</b></small> -->
                    <small v-if="prop.data.storeCode">Google Store Code: <b>{{ prop.data.storeCode }}</b></small>
                </div>
            </div>
        </div>

        <div v-if="prop.type == TableDataTypes.ParagraphList">
            <p v-for="paragraph in prop.data">{{ paragraph }}</p>
        </div>

        <div v-if="prop.type == TableDataTypes.DayTimeGroup">
            <ul class="day-time-group">
                <li v-for="item in prop.data">
                    <div class="day-title">{{ item.day }}</div>
                    <div class="day-time">{{ item.time }}</div>
                </li>
            </ul>
        </div>

        <template v-if="prop.type == TableDataTypes.Services">
            <div>
                <ul class="service-group" :class="{ 'sync-service': !item.HideDescription }" v-for="item in prop.data">
                    <li>
                        <span class="service-label">Category:</span>
                        <span><b>{{ item.CategoryDisplayName }}</b></span>
                    </li>
                    <li>
                        <span class="service-label">Name:</span>
                        <span><b>{{ item.ServiceDisplayName }}</b></span>
                    </li>
                    <li v-if="!(item.Description == '' || item.Description == null)">
                        <span class="service-label">Description:</span>
                        <p>{{ item.Description }}</p>
                    </li>
                </ul>
            </div>
            <!-- <Skbutton button-text="View More" link-text /> -->
        </template>
        <!-- Todo Need to change it to component -->
        <div v-if="prop.type == TableDataTypes.Icon" class="sk-flex">{{ prop.data.title }} <div
                class="sk-tooltip-rich sk-tooltip-right">
                <span class="sk-icons sk-tooltip-trigger">report_problem</span>
                <div class="sk-tooltip-wrapper">
                    <div class="sk-tooltip-inner">
                        <p>{{ prop.data.tooltip }}</p>
                    </div>
                </div>
            </div>
        </div>

        <a v-if="prop.type == TableDataTypes.Anchor" :href="prop.data.href" :target="prop.data.isBlank ? '_blank' : '_self'">
            {{ prop.data.innerText }}
        </a>

        <div class="sk-flex-row sk-no-wrap" v-if="prop.type == TableDataTypes.Avatar">
            <div class="sk-avatar sk-small">
                <img v-if="prop.data.avatarLink" :src="prop.data.avatarLink">
                <img v-else src="https://profiles.sulekhalive.com/common/images/no-image-thumb.jpg">
            </div>
            <div class="user-details">
                <span @click="prop.data.action(prop)">{{ prop.data.avatarText }}</span>
                <span class="role">{{ prop.data.role }}</span>
            </div>
        </div>

        <div v-if="prop.type == TableDataTypes.IconWithText" class="sk-flex sk-no-wrap sk-flex-align-start">
            <SkIcon :icon-type="prop.data.iconType" :success="prop.data.success" :danger="prop.data.danger"
                :warning="prop.data.warning" />
            <span>{{ prop.data.iconText }}</span>
        </div>

        <div v-if="prop.type == TableDataTypes.AttributeSentimentBreakUp" class="ratings-table sk-flex-row sk-no-wrap">
            <div v-if="prop.data.positivePercent" class="sk-bg-success"
                :style="{ width: `${Math.round(prop.data.positivePercent)}%` }">
            </div>
            <div v-if="prop.data.neutralPercent" class="sk-bg-warning"
                :style="{ width: `${Math.round(prop.data.neutralPercent)}%` }">
            </div>
            <div v-if="prop.data.negativePercent" class="sk-bg-danger"
                :style="{ width: `${Math.round(prop.data.negativePercent)}%` }">
            </div>
        </div>
        <div class="sk-flex" v-if="prop.type == TableDataTypes.SyncProperty">
            {{ prop.data.propertyName }}

            <SkToolTip :direction="ToolTipDirection.Right" v-if="prop.data.isSensitive" :show="prop.data.isSensitive">
                <template #SkTooltip>
                    <SkIcon class="sk-tooltip-trigger" icon-type="report_problem" />
                </template>
                <template #SkTooltipContent>{{ prop.data.warningText }}</template>
            </SkToolTip>

            <SkToolTip :direction="ToolTipDirection.Right" v-if="prop.data.hasPendingEdit" :show="prop.data.hasPendingEdit">
                <template #SkTooltip>
                    <SkIcon filled icon-type="schedule" />
                </template>
                <template #SkTooltipContent>{{ prop.data.pendingEditToolTipText }}</template>
            </SkToolTip>
        </div>
        <div v-if="prop.type == TableDataTypes.LineClamp" :class="`sk-line-clamp sk-line-${prop.data.lineToClamp}`"
            :title="prop.data.text">
            {{ prop.data.text }}
        </div>
        <div v-if="prop.type == TableDataTypes.TitleText" class='sk-truncate review-para-id'
            :title="prop.data.text">
            {{ prop.data.text }}
        </div>
        <div v-if="prop.type == TableDataTypes.TextToolTip " class ='sk-flex-row'>
            {{ prop.data.text }}
            <SkToolTip :direction="ToolTipDirection.Right" v-if = "prop.data.isDifferent == 1 " show>
                <template #SkTooltip>
                    <SkIcon class="sk-tooltip-trigger" icon-type="info" />
                </template>
                <template #SkTooltipContent>{{ prop.data.warningText }}</template>
            </SkToolTip>
        </div>
        <div v-if="prop.type == TableDataTypes.CustomDomain" class="sk-flex-row">
            <button v-if ="prop.data.showConnectDomain" @click="prop.data.action" class="sk-button sk-small sk-button-link sk-no-shadow">
                <span class="sk-icons">add_link</span>
                <span class="sk-button-text">Connect Domain</span>
                <span class="sk-ripple-container"></span>
            </button>
                <div class="sk-flex sk-clickable">
                    <a class="sk-text-muted" title="" :href="prop.data.url" target="_blank">{{ prop.data.url }}</a>
                    <span class="sk-icons">open_in_new</span>
                </div>
        </div>
        <Skpopup v-if="prop.type == TableDataTypes.OverFlowMenu" :popup-action-items="prop.data.overFlowItems"
            @overflow-menu-click="prop.data.onItemSelect" :trigger-button="prop.data.triggerButton" :showOnlyIcon="prop.data.showOnlyIcon" />

        <div v-if="prop.type == TableDataTypes.OverFlowElipsis" class="group-more-list sk-flex-row">
            <span>{{ prop.data.length > 1 ? prop.data.slice(0, 1).join() :
                prop.data.at(0) }}</span>
            <SkToolTip :direction="ToolTipDirection.Bottom" v-if="prop.data.length > 1" show>
                <template #SkTooltip>
                    <span>+{{ prop.data.length - 1 }}</span>
                </template>
                <template #SkTooltipContent>
                    <div class="sk-overflow-list sk-show">
                        <ul>
                            <li v-for="item in prop.data.slice(1, prop.data.length)">{{ item }}</li>
                        </ul>
                    </div>
                </template>
            </SkToolTip>
        </div>
        <div  class="chat-status-group" v-if="prop.type == TableDataTypes.ToggleSwitch">
            <div class="sk-switch sk-primary">
                <label>
                    <input type="checkbox" :checked="prop.data.isChecked" @change="prop.data.action()"/><span class="lever"></span>
                </label>
            </div>
            <SkLoader ref="spinnerLoader"></SkLoader>
            <div class="sk-loader sk-small">
                <div class="sk-loader-inner">
                    <div class="sk-spinner-loader">
                        <svg class="sk-circular" viewBox="25 25 50 50">
                            <circle class="sk-path" cx="50" cy="50" r="20" fill="none" stroke-miterlimit="10"></circle>
                        </svg>
                    </div>
                    <div class="sk-loader-text">In Progress...</div>
                </div>
            </div>

        </div>
        <SkSwitch v-if="prop.type == TableDataTypes.Toggle"
            :isChecked="prop.data.isChecked"
            :secondary="prop.data.color == 'secondary'"
            :link="prop.data.color == 'link'"
            :success="prop.data.color == 'success'"
            :warning="prop.data.color == 'warning'"
            :size="prop.data.size"
            :leadingText="prop.data.leadingText"
            :trailingText="prop.data.trailingText"
            :isWide="prop.data.isWide"
            :disabled="prop.data.disabled"
        />
        <div v-if="prop.type == TableDataTypes.HtmlString" v-html="prop.data">
        </div> 

        <div v-if ="prop.status && prop.status.text" :class="prop.status.class">{{ prop.status.text }}</div>
        <div v-if="prop.type == TableDataTypes.DropDown" class="sk-flex-row sk-no-wrap">
            <Skdropdown :place-holder-text="prop.data.actionPlaceHolderText" has-floating-label
                                :listItems="prop.data.overFlowItems"
                                :size= "HtmlItemSizeOptions.Small"
                                :is-disabled="prop.data.actionDisabled"
                                @update:modelValue="prop.data.onItemSelect">
            </Skdropdown>
            <Skdropdown v-if="prop.data.overFlowSubItems && prop.data.overFlowSubItems.length" 
                                :place-holder-text="prop.data.subActionPlaceHolderText" has-floating-label
                                :listItems="prop.data.overFlowSubItems"
                                :size= "HtmlItemSizeOptions.Small"
                                @update:modelValue="prop.data.onStatusSelect">
            </Skdropdown>
            <button :disabled="prop.data.disabled" class="sk-button"
            :class="prop.data.buttonClassList" @click="prop.data.action">Update</button>
        </div>
        <div v-if="prop.type == TableDataTypes.BusinessFormat">
            <div class="sk-h7 sk-font-bold sk-link sk-clickable" @click="prop.data.action()"> 
                {{prop.data.businessName}} 
            </div>
            <p class="sk-h8 sk-text-muted sk-margin-bottom-0"> {{ prop.data.formattedAddress }} </p>
        </div>

        <div v-if="prop.type == TableDataTypes.ToolTipBadge">
            <div class='sk-tooltip-rich sk-tooltip-right'>
                <div class='sk-tooltip-trigger'>
                    <span class='sk-icons'>
                        <svg width='30' height='30'>
                            <use :xlink:href='prop.data.svgId'>
                            </use>
                        </svg>
                    </span>
                </div>
                <div class='sk-tooltip-wrapper sk-show'>
                    <div class='sk-tooltip-inner'>
                        <p>{{prop.data.toolTipText}}</p>
                    </div>
                </div>
            </div>
        </div>

        <div v-if="prop.type == TableDataTypes.TextWithColorBG" :class="`sk-badge sk-bg-${prop.data.class}`">
            {{ prop.data.statusText }}
        </div>
    </td>
    <td v-else-if="prop.dataType == 'html'" :class="[prop.hide ? 'sk-hide' : '', prop.class]">
        <div v-html="prop.data"></div>
    </td>
    <td v-else :class="[prop.hide ? 'sk-hide' : '', prop.class]">
        {{ prop.data }}
    </td>
</template>