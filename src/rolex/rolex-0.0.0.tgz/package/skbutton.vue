<script lang="ts">
export default {
	name: 'SkButton',
};
</script>

<script setup lang="ts">
// define all the customizable properties
import { computed } from 'vue';
import SkIcon from './skicon.vue';
interface Props {
	// Need to add many props variant to the button
	//Common
	buttonText?: string; // Text in the button
	block?: boolean; // Block level button (full width)
	disabled?: boolean; // Disable the button
	round?: boolean; // Applies cirlce type button
	rounded?: boolean; // Applies corner rounded radius button
	pill?: boolean; // Applies corner pill style radius button
	fab?: boolean; // Applies FAB style button

	//Button size (Default is medium size button )
	xlarge?: boolean; // Extra large size button
	large?: boolean; // Large size button
	small?: boolean; // Small size button
	// xsmall?: boolean;

	//Filled button
	primary?: boolean; // Primary
	secondary?: boolean; // Secondary
	light?: boolean; // Light version
	dark?: boolean; // Dark version
	link?: boolean; // Link version
	success?: boolean; // Success version
	danger?: boolean; // Danger version
	warning?: boolean; // Warning version
	info?: boolean; // Info version
	grey?: boolean; // Grey version

	// Outlined button
	outline?: boolean; // Primary outline
	secondaryOutline?: boolean; // Secondary outline
	lightOutline?: boolean; // Light outline
	darkOutline?: boolean; // Dark outline
	linkOutline?: boolean; // Link outline
	successOutline?: boolean; // Success outline
	dangerOutline?: boolean; // Danger outline
	warningOutline?: boolean; // Warning outline
	infoOutline?: boolean; // Info outline
	greyOutline?: boolean; // Grey outline

	// Text version
	primaryText?: boolean; // Primary text only
	secondaryText?: boolean; // Secondary text only
	lightText?: boolean; // Light text only
	darkText?: boolean; // Dark text only
	linkText?: boolean; // Link text only, Padding by default removed. Need to rethink this.
	successText?: boolean; // Success text only
	dangerText?: boolean; // Danger text only
	warningText?: boolean; // Warning text only
	infoText?: boolean; // Info text only
	greyText?: boolean; // Grey text only
	flat?: boolean; // Need to check and remove if not required or need to regularize

	//Icons (Need to refactor this svg icon / font icon usage)
	useSvg?: boolean;
	icon?: string;
	IconStyle?: string;
	iconSize?: string;
	iconRotate?: boolean;
	svgIcon?: string;

	//Miscellanous    
	badge?: string;  
	webHide?: boolean;
	mobileHide?: boolean;    
	badgeType?: string;
	tooltipType?: string;  
	trailingIcon?: string; // Need to check and remove if not required
	isLoaderEnabled?: boolean; // To enable / disable the spinner loader
	isLoaderLeading?: boolean; // Enable leading spinner loader
	isLoaderTrailing?: boolean; // Enable trailing spinner loader
	noPadding?:boolean; // To remove padding left & right to the any button

	// Need to check and remove/refactor if not used
	notificationcount?: number; // Need to check and remove if not required
	noShadow?: boolean; // Need to check and remove if not required
	leadingIcon?: boolean; // Need to check and remove if not required
	hide?: boolean;
}

const props = defineProps<Props>();
const badgeComputed = computed(() => {
	if (props.badgeType == 'icon') return '';

	return props.badge;
});
</script>

<template>
	<button
		:disabled="disabled"
		class="sk-button"
		:class="{
			'sk-hide': hide,
			'sk-block': block,
			'sk-round': round,
			'sk-rounded': rounded,
			'sk-pill': pill,
			'sk-xlarge': xlarge,
			'sk-large': large,
			'sk-small': small,
			// 'sk-xsmall': xsmall,

			'sk-primary': primary,
			'sk-secondary': secondary,
			'sk-light': light,
			'sk-dark': dark,
			'sk-link': link,
			'sk-success': success,
			'sk-danger': danger,
			'sk-warning': warning,
			'sk-info': info,
			'sk-grey': grey,

			'sk-primary-outline': outline,
			'sk-secondary-outline': secondaryOutline,
			'sk-light-outline': lightOutline,
			'sk-dark-outline': darkOutline,
			'sk-link-outline': linkOutline,
			'sk-success-outline': successOutline,
			'sk-danger-outline': dangerOutline,
			'sk-warning-outline': warningOutline,
			'sk-info-outline': infoOutline,
			'sk-grey-outline': greyOutline,

			'sk-primary-text': primaryText, //Need to apply proper css class name & props name for flat/plain buttons
			'sk-secondary-text': secondaryText,
			'sk-light-text': lightText,
			'sk-dark-text': darkText,
			'sk-button-link': linkText,
			'sk-success-text': successText,
			'sk-danger-text': dangerText,
			'sk-warning-text': warningText,
			'sk-info-text': infoText,
			'sk-grey-text': greyText,

			'sk-web-hide': webHide,
			'sk-mobile-hide': mobileHide,
			'sk-no-padding':noPadding,

			'sk-fab': fab, // Applies to style FAB Button
			'sk-button-loader': isLoaderEnabled, // enable or disable the loader
			'sk-loader-leading': isLoaderLeading, // Enable leading loader
			'sk-loader-trailing': isLoaderTrailing, // Enable trailing loader

			'sk-no-shadow': noShadow, // Need to check and remove if not required
			'sk-leading-icon': leadingIcon, // Need to check and remove if not required
			//'sk-trailing-icon': trailingIcon, // Need to check and remove if not required
			'sk-flat': flat, // Need to check and remove if not required
    	}"
 	>
	<div v-if="isLoaderEnabled || isLoaderLeading" class="sk-spinner-loader">
		<svg class="sk-circular" viewBox="25 25 50 50">
			<circle class="sk-path" cx="50" cy="50" r="20" fill="none" stroke-miterlimit="10"></circle>
		</svg>
	</div>
    <SkIcon
      v-if="icon && icon != ''"
      :tooltip="tooltipType"
      :iconType="icon"
      :iconSize="iconSize"
	  :isColorPrimary="primaryText"
	  :warning="warningText"
    />
    <SkIcon
      v-if="svgIcon && svgIcon != ''"
      :tooltip="tooltipType"
      :svgIcon="svgIcon"
      :iconSize="iconSize"
    />
    <span v-if="badge != undefined && badge !== ''" class="sk-badge">
      <SkIcon
        class="bot-status"
        :tooltip="tooltipType"
        v-if="badgeType != undefined && badgeType == 'icon'"
        >{{ badge }}
      </SkIcon>
      {{ badgeComputed }}
    </span>
    <span class="sk-button-text">{{ buttonText }}</span>	
    <SkIcon
      v-if="trailingIcon && trailingIcon != ''"
      :tooltip="tooltipType"
      :iconType="trailingIcon"
      :iconSize="iconSize"
    />
    <slot name="buttoninner"></slot>
	<div v-if="isLoaderEnabled" class="sk-spinner-loader"> 
		<svg class="sk-circular" viewBox="25 25 50 50"> 
			<circle class="sk-path" cx="50" cy="50" r="20" fill="none" stroke-miterlimit="10"></circle> 
		</svg> 
	</div>
	<!-- Ripple Effect -->
	<span class="sk-ripple-container"></span>
  </button>
</template>
