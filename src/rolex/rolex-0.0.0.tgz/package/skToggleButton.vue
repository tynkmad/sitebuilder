<script lang="ts">
export default {
    name: "SkToggleButton",
};
</script>
<script setup lang="ts">
import { ISkToggleButtonValue } from "./skglobaltypes";

interface Props {
    values: Array<ISkToggleButtonValue>
}

const props = defineProps<Props>();

const emit = defineEmits(["onChange"]);
defineExpose({

});

function onChange(value: ISkToggleButtonValue) {
    props.values.forEach(x => {
        x.isChecked = x.name == value.name;
    });
    emit('onChange', props.values.find(x => x.isChecked));
}

</script>
<template>
    <div class="sk-toggle-button">
        <label v-for="item in values" :for="item.name" class="sk-check-label" :class="{'sk-toggle-active': item.isChecked}">{{
            item.name }}
            <input :id="item.name" name="toggle" type="radio" :checked="item.isChecked" @change="onChange(item)">
        </label>
        <div class="sk-toggle-animate"></div>
    </div>
</template>
