<script setup lang="ts">
import { computed } from 'vue';

interface prop{
    rating:string |number;
}
const props=defineProps<prop>();

    const starRating=computed(() =>{
        let ratings=props.rating.toString()
    return ((+ratings.charAt(2)) > 0 && +ratings.charAt(2)<6)?("sk-star sk-star"+ratings.charAt(0)):("sk-star sk-star"+ratings.charAt(0))
}) 

</script>
<template>
    <span :class=starRating></span>
</template>