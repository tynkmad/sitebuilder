import { HTMLAttributes } from 'vue';

export interface textField {
  key: string;
  errorText: string;
  labelText: string;
  inputValue?: string;
  countryCode?: number;
  inputType: string;
  inputMaxLength?: number;
  inputMode?: HTMLAttributes["inputmode"];
  pattern?: string;
}

export enum TableDataTypes {
  None = 0,
  Growth = 1,
  Sentiment = 2,
  StarRating = 3,
  Link = 4,
  PlatForms = 5,
  Button = 6,
  Badge = 7,
  BadgeWithText = 8,
  Paragraph = 9,
  Chip = 10,
  CheckBox = 11,
  ButtonGroup = 12,
  TitleAndContent = 13,
  ParagraphList = 14,
  DayTimeGroup = 15,
  Services = 16,
  Icon = 17,
  Anchor = 18,
  Avatar = 19,
  LineClamp=20,
  SyncProperty=21,
  IconWithText = 22,
  AttributeSentimentBreakUp = 23,
  OverFlowMenu = 24,
  OverFlowElipsis = 25 ,
  Toggle = 26,
  HtmlString = 27,
  TitleText = 28,
  TextToolTip = 29,
  CustomDomain = 30,
  DropDown = 31, 
  ToggleSwitch = 32,
  BusinessFormat =33,
  ToolTipBadge = 34,
  TextWithColorBG = 35
}

export enum TableHeaderTypes {
  Sortable,
}

export enum ColorTypes {
  Success = "success",
  Warning = "warning",
  Danger = "danger"
}
interface ITable {
  header?: Array<ITableHead>,
  defaultHeader?: Array<string>,
  rows: Array<ITableRow>,
  tableLoaded?: boolean,
  flat?: boolean,
  hover?: boolean,
  striped?: boolean
}

interface ISKDropDown {
  listItems: Array<listItemType>;
  isNativeSelect?: boolean;
  placeHolderText: string;
  itemTitle?: string;
  size?: HtmlItemSizeOptions;
  hasFloatingLabel?: boolean;
  hasError?: boolean;
  errorText?: string;
  helperText?: string;
  hasMultiSelectOption?: boolean;
  isMandatory?: boolean;
  dropDowninitialValue?: string; // Need to check and remove if not required
  selectedItem?: string;
  useIcon?: boolean;
  iconType?: string;
  prefixText?: string;
  showChannelImage?: boolean
  useSvg?: boolean;
}


interface ITableHead {
  sortable?: boolean,
  title?: string,
  noSort?: boolean,
  isAscending?: boolean,
  checkBox?: boolean,
  isChecked?: boolean,
  image?: string,
  hide?: boolean,
  dropDown?: ISKDropDown,
  action?: (x: ITableHead) => any,
  disable?: boolean,
  additionalStyle?: string
}
interface ITableRow {
  hide?: boolean,
  isHideable?: boolean,
  isSelected?: boolean,
  rowValue?: any,
  tableDataList: Array<ITableData>
}

interface ITableData {
  type?: TableDataTypes,
  data: any,
  hide?: boolean,
  class?: string,
  dataType?: 'html' | 'string'
  status?: {
    text: string,
    class:string
  }
}

interface IListItem {
  key: any,
  value: any,
  isSelected?: boolean,
  removable?: boolean
}

interface listItemType {
  itemKey: string;
  itemValue?: object;
  itemTitle?: string;
  isSelected?: boolean;
  disabled?: boolean;
  hide?: boolean;
}

export interface dropdownProps {
  key: string;
  listItems: Array<listItemType>;
  size: HtmlItemSizeOptions;
  isNativeSelect: boolean;
  placeHolderText: string;

  hasError?: boolean;
  hasFloatingLabel?: boolean;

  errorText?: string;
  helperText?: string;
  hasMultiSelectOption?: boolean;
  isMandatory?: boolean;
}

export interface chipProps {
  key: string;
  chipMessage: string;
  icon?: string;
  imgUrl?: string;
  chipId?: string
  selected?: boolean;
  removable?: boolean;
  withCount?: boolean;
  chipCount?: number;
  xsmall?: boolean;
  small?: boolean;
  filled?: boolean;
  disabled?: boolean;
}

interface skActionItem {
  itemKey: string;
  actionIcon?: string;
  actionlabel?: string;
  //actionItems for #consumerApp AppBar start
  iconSize?: string;
  iconStyle?: string;
  buttonStyle?: string;
  isActive?: boolean;
  useSvg?: boolean;
  //actionItems for #consumerApp AppBar end
  badge?: string;
  badgeType?: string;
  tooltipType?: string;
  webHide?: boolean;
  mobileHide?: boolean;
  isColorPrimary?:boolean;
}
export interface routerType {
  navIcon: string;

  navIconHeight?: string;

  navIconWidth?: string;



  navBtnName: string;

  isActive?: boolean;

  routeName: string;

  routerButton: string;
}

export interface skChatTemplateType {
  chatTemplateMessage: string;
  chatTemplateGreeting: string;
  icon: string;
  buttonstyle: string;
  buttontext: string;
}

export interface ISlkAPIDialog {
  runningCount: number;
  loadMessage?: string;
  hadError: boolean;
  errorMessage?: string;
}

export interface ISlkToast {
  message: string;
  interval: number;
  type?: ToastType;
  options?: ISlkToastOptions | undefined;
}

export enum ToastType {
  Default,
  Info,
  Success,
  Error,
  Warning,
}
export interface MainNavBarType {
  menuName: any; isActive?: Boolean; targetContentID?: String; image?: string;icon?: string;isDisabled?: boolean;hide?:boolean;
}

export interface ISlkToastOptions {
  actions: Array<ISlkToastActions>;
}

export interface ISlkToastActions {
  text: string;
  actionCallback?: string;
}
interface ISkButtonGroupItem {
  buttonText?: string,
  classList?: Array<string>,
  action?: () => any,
  toolTipClass?: Array<string>
}

interface ISkButtonGroupItem {
  buttonText?: string,
  classList?: Array<string>,
  action?: () => any,
  toolTipClass?: Array<string>
}

interface ISkButtonGroupItem {
  buttonText?: string,
  classList?: Array<string>
  action?: () => any,
  disabled?: boolean
}

interface ISkButton {
  // Need to add many props variant to the button
  //Common
  buttonText?: string; // Text in the button
  block?: boolean; // Block level button (full width)
  disabled?: boolean; // Disable the button  
  round?: boolean; // Applies cirlce type button
  rounded?: boolean; // Applies rounded corner radius type button
  fab?: boolean; // Applies FAB style button

  //Button size (Default is medium size button )
  xlarge?: boolean; // Extra large size button
  large?: boolean; // Large size button
  small?: boolean; // Small size button
  xsmall?: boolean; // Extra small size button

  //Filled button
  primary?: boolean; // Primary
  secondary?: boolean; // Secondary
  light?: boolean; // Light version
  dark?: boolean; // Dark version
  link?: boolean; // Link version
  success?: boolean; // Success version
  danger?: boolean; // Danger version
  warning?: boolean; // Warning version
  info?: boolean; // Info version
  gray?: boolean; // Gray version

  // Outlined button
  outline?: boolean; // Primary outline
  secondaryOutline?: boolean; // Secondary outline
  lightOutline?: boolean; // Light outline
  darkOutline?: boolean; // Dark outline
  linkOutline?: boolean; // Link outline
  successOutline?: boolean; // Success outline


  // Text version
  primaryText?: boolean; // Primary color text only
  linkText?: boolean; // Link color text only

  //Icons (Need to refactor this svg icon / font icon usage)
  useSvg?: boolean;
  icon?: string;
  IconStyle?: string;
  iconSize?: string;
  iconRotate?: boolean;
  svgIcon?: string;

  //Miscellanous    
  badge?: string;
  webHide?: boolean;
  mobileHide?: boolean;
  badgeType?: string;
  tooltipType?: string;

  // Need to check and remove/refactor if not used
  notificationcount?: number; // Need to check and remove if not required
  noShadow?: boolean; // Need to check and remove if not required
  leadingIcon?: boolean; // Need to check and remove if not required
  trailingIcon?: boolean; // Need to check and remove if not required
  flat?: boolean; // Need to check and remove if not required
  hide?: boolean;
  // callBackAction from Buttons in Button Group
  action: () => any
}
interface ISkToggleButtonValue {
  name: string,
  isChecked: boolean
}
export type {
  listItemType,
  skActionItem,
  ITable,
  ITableData,
  ITableRow,
  IListItem,
  ITableHead,
  ISKDropDown,
  ISkButton,
  ISkToggleButtonValue
};

export enum HtmlItemSizeOptions {
  Default = 0,
  Small = 1,
  Large = 2,
  ExtraLarge = 3,
}
