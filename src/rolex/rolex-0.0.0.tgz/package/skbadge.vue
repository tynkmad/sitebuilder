<script lang="ts">
export default {
  name: "SkBadge",
};
</script>

<script setup lang="ts">
import { computed } from "vue";
import skIcon from "./skicon.vue";
// define all the customizable properties
interface Props {
  badge?: string; // Pass the badge value string
  badgeType?: string; // TODO :: Need clarification on this props, Need to rewrite
  small?: boolean; // Smaller size TODO :: Need clarification on this props, Need to rewrite
  primary?: boolean; //Neutral color.
  secondary?: boolean; // Secondary color
  success?: boolean; // Success color
  danger?: boolean; // Danger color
  dark?: boolean; // Dark color
  round?: boolean; // Border radius
  warning?: boolean; //Neutral color.
}

const props = defineProps<Props>();
const badgeComputed = computed(() => {
  if (props.badgeType == "icon") return "";

  return props.badge;
});
</script>

<template>
  <span
    class="sk-badge"
    :class="{
      'sk-badge-small': small,
      'sk-badge-primary': primary,
      'sk-badge-secondary': secondary,
      'sk-badge-success': success,
      'sk-badge-danger': danger,
      'sk-badge-dark': dark,
      'sk-badge-round': round,
      'sk-badge-warning': warning,
    }"
  >
    <slot name="badgeinner"></slot>
    {{ badgeComputed }}
  </span>
</template>
