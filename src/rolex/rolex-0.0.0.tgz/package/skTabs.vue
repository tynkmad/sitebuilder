<script setup lang="ts">
import SkMenuBar from './skMenuBar.vue';
export interface menuNames {
  menuName: any;
  isActive?: boolean;
  targetContentID?: string;
  image?:string;
  icon?:string;
  isDisabled?: boolean;
  hide?: boolean;
}
interface prop {
  tabMenuItem: Array<menuNames>;
  isVerticalTab?: boolean
  enablePadding?: boolean
  bgColorEnable?:boolean
  surface?: boolean
  additionalClass?: string
  sticky?: boolean
  menuStickyTopLevel?: string
  mobileHorizontal?:boolean
  stickyTopScroll?:boolean
  useSmallMenu?:boolean
}
const emit = defineEmits(['tabMenuBarOnClick'])
const onClickTabMenu = ((MenuId: String) => {
  emit('tabMenuBarOnClick', MenuId)
})
const props = defineProps<prop>();
</script>
<template>
  <div class="sk-tabs" :class="{ 'sk-vertical': isVerticalTab, 'sk-surface': surface, 'sk-mobile-horizontal':mobileHorizontal}">
    <div class="sk-tab-menu" :class="{'sticky-top-scroll':stickyTopScroll}">
      <SkMenuBar :useSmallMenu="useSmallMenu" :sticky="sticky" :stickyTopLevel="menuStickyTopLevel" :stickyTopScroll="stickyTopScroll" :bgColor="bgColorEnable" :MenuItems="tabMenuItem" scrollable
        @navBarNavigation="(targetContentID) => onClickTabMenu(targetContentID)"></SkMenuBar>
    </div>
    <div class="sk-tab-header">
      <slot name="skTabheader"></slot>
    </div>
    <div class="sk-tab-content">
      <div class="sk-tab-data sk-active" :class="{ 'sk-padding-0': !enablePadding }">
        <slot name="skTabcontent">

        </slot>
      </div>
    </div>
  </div>
</template>