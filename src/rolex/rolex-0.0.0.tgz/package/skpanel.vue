<script lang="ts">
export default {
	name: 'SkPanel',
};
</script>
<script setup lang="ts">
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup

import { watch, ref } from 'vue';
import { toggleBodyNoScroll } from './utilFunctions';

interface Props {
	id?: string;
	panelstyle?: string;
	showPanel: boolean;
	small?: boolean;
	large?: boolean;
	xLarge?: boolean;
	fullScreen?: boolean;
	fixedHeight?: boolean;
	zIndexTopLayer?: boolean; // this props using top most layer to the z-index property. if similiar two panels rendering that time this prop use it.
	innerClass?: string;
	panelBodyId?: string;
}

const panelBodyContainer = ref<HTMLElement | null>(null);

function closePanel() {
	emit('closePanel');
}

const handlePanelBodyScroll = () => {

if (!panelBodyContainer.value) {
  return;
}

emit('handlePanelBodyScroll', panelBodyContainer.value)
};

const emit = defineEmits(['closePanel', 'handlePanelBodyScroll']);

const props = defineProps<Props>();

watch(props, () => {
	toggleBodyNoScroll(props.showPanel);
});
</script>
<template>
	<div
		class="sk-panel"
		:class="{
			'sk-show': showPanel,
			'sk-panel-fullscreen': fullScreen,
			'sk-fixed-height': fixedHeight,
			'sk-panel-small': small,
			'sk-panel-large': large,
			'sk-panel-xlarge': xLarge,
			'sk-top-layer': zIndexTopLayer,
		}"
		:id="id">
		<div class="sk-panel-container">
			<div class="sk-panel-inner" :class="`${innerClass ? innerClass : ''}`">
				<!-- Panel Header :: BEGIN -->
				<div class="sk-panel-header">
					<slot name="skpanelheader"></slot>
				</div>
				<div class="sk-panel-body" :id="panelBodyId" ref="panelBodyContainer" @scroll="handlePanelBodyScroll">
					<slot name="skpanelbody"></slot>
				</div>
				<div class="sk-panel-footer">
					<slot name="skpanelfooter"></slot>
				</div>
			</div>
		</div>
		<div class="sk-backdrop"></div>
	</div>
</template>
