<script lang="ts">
export default {
  name: "SkDropDown",
};
</script>

<script setup lang="ts">
import { ref, computed, watch, reactive, onMounted } from "vue";
import {
  listItemType,
  HtmlItemSizeOptions,
  ISKDropDown,
} from "./skglobaltypes";
import { useOnClickOutside } from "./onClickOutside";
import SkButton from "./skbutton.vue";
import SkCheckbox from "./skcheckbox.vue";
import Channelimg from "./channelimg.vue";
import SkIcon from "./skicon.vue";

// input - a list of items to display
// emits item selected event or list of selected items in case of multiselect

interface Props {
  listItems: Array<listItemType>;
  isNativeSelect?: boolean;
  placeHolderText?: string;
  // Define list of items
  itemTitle?: string;
  size?: HtmlItemSizeOptions;
  hasFloatingLabel?: boolean;
  lableText?:string;
  hasError?: boolean;
  errorText?: string;
  helperText?: string;
  hasMultiSelectOption?: boolean;
  isMandatory?: boolean;
  dropDowninitialValue?: string;
  // Need to clarify for the below props
  selectedItem?: string;
  useIcon?: boolean;
  iconType?: string;
  prefixText?: string;
  showChannelImage?: boolean;
  useSvg?: boolean;
  isMobileHide?: boolean;
  isWebHide?: boolean;
  isListBottomSheet?: boolean;
  //This props not used anywhere, check and remove if not required
  skTextEnd?: boolean;
  hideDefaultIcon?: boolean;
  defaultValue?: Array<listItemType>;
  isDisabled?: boolean;
  iconOnlyForMobile?: boolean;
}

const props = defineProps<Props>();

interface IReactiveData {
  showOptions: boolean;
  selectedItems: Array<listItemType>;
}

let dataDefaults: IReactiveData = {
  showOptions: false,
  selectedItems: props.defaultValue ? props.defaultValue : [],
};

let ReactiveData = reactive(dataDefaults);
const showOptions = ref(false);
const selected = ref(props.placeHolderText);
const emit = defineEmits(["update:modelValue", "submitMultiSelect", "onClick"]);

let selectedValue = computed(() => {
  let returnValue: string = "";
  if (props.hasMultiSelectOption && ReactiveData.selectedItems.length)
    returnValue = GetReturnValueForMultiselect();
  else if (ReactiveData.selectedItems.length > 0)
    returnValue = ReactiveData.selectedItems[0] ? ReactiveData.selectedItems[0].itemTitle || "" : "";
  else if (!props.hasFloatingLabel) returnValue = props.placeHolderText || "";
  return returnValue;
});

watch(selected, (selected) => {
  let item = props.listItems.find((f) => f.itemTitle == selected);
  if (item != undefined) {
    ReactiveData.selectedItems.push(item);
    emit("update:modelValue", ReactiveData.selectedItems[0]);
  }
});

function showOptionsClick() {
  showOptions.value = !showOptions.value;
  emit("onClick")
}

function setSelectedItem(item: listItemType) {
  ReactiveData.selectedItems[0] = item;
}

function setDefaultMultiSelectItems(items: Array<listItemType>) {
  ReactiveData.selectedItems = items;
}

function getSeletedItem() {
  return ReactiveData.selectedItems[0]
    ? ReactiveData.selectedItems[0]
    : props.listItems[0];
}

function selectOptionClick(evt: Event, item: listItemType) {
  showOptions.value = !showOptions.value;
  setSelectedItem(item);
  emit("update:modelValue", ReactiveData.selectedItems[0]);
  evt.stopPropagation();
}

const skdropdownselect = ref<HTMLElement | null>(null);
onMounted(() => {
  useOnClickOutside(skdropdownselect, () => {
    if (
      props.hasMultiSelectOption &&
      ReactiveData.selectedItems.length > 0 &&
      showOptions.value
    ) {
      submitSelected();
    }
    if (showOptions.value) {
      showOptions.value = !showOptions.value;
    }
  });
});

function submitSelected() {
  emit("submitMultiSelect", ReactiveData.selectedItems);
  showOptions.value = false;
}

function onResetClick() {
  props.listItems.forEach((item) => {
    item.isSelected = false;
    item.disabled = false;
  });
  ReactiveData.selectedItems = [];
  submitSelected();
}

function checkBoxClicked(item: listItemType) {
  if (item.disabled) return;

  item.isSelected = !item.isSelected;

  if (item.itemKey == '-1') {
    if (item.isSelected)
      ReactiveData.selectedItems = [];
    props.listItems.forEach((x) => {
      if (x.itemKey != '-1') {
        x.isSelected = item.isSelected;
        x.disabled = item.isSelected;
      }
    })
  }


  if (
    ReactiveData.selectedItems.findIndex((x) => x.itemKey == item.itemKey) == -1
  ) {
    ReactiveData.selectedItems.push(item);
  } else {
    ReactiveData.selectedItems.splice(
      ReactiveData.selectedItems.findIndex((x) => x.itemKey == item.itemKey),
      1
    );
  }
}

function GetReturnValueForMultiselect(): string {
  return ReactiveData.selectedItems.length > 1
    ? ReactiveData.selectedItems[0].itemTitle +
    " + " +
    (ReactiveData.selectedItems.length - 1).toString() || ""
    : ReactiveData.selectedItems[0].itemTitle || "";
}

defineExpose({
  setSelectedItem,
  onResetClick,
  getSeletedItem,
  setDefaultMultiSelectItems
});
</script>

<template>
  <div
    ref="skdropdownselect"
    class="sk-text-select"
    :class="{
      'sk-error': hasError,
      'sk-focus': showOptions,
      'sk-valid': ReactiveData.selectedItems.length > 0 && !hasError,
      'sk-small': size == HtmlItemSizeOptions.Small,
      'sk-large': size == HtmlItemSizeOptions.Large,
      'sk-xlarge': size == HtmlItemSizeOptions.ExtraLarge,
      'sk-mobile-hide': isMobileHide,
      'sk-web-hide': isWebHide,
      'sk-text-end': skTextEnd,
      'sk-disabled': isDisabled,
      'sk-mobile-icon': iconOnlyForMobile,
    }"
   
  >
    <div class="sk-event-group"  @click="showOptionsClick">
      <SkIcon v-if="useIcon" :icon-type="iconType" :class="{'sk-web-hide sk-mobile-icon': iconOnlyForMobile}"/>
      <span class="prefix-text" v-if="prefixText">{{ prefixText }}</span>
      <select v-if="isNativeSelect" v-model="selected">
        <option :key="-1" disabled :value="placeHolderText" v-if="placeHolderText != ''">
          {{ placeHolderText }}
        </option>
        <option v-for="item in listItems" :key="item.itemKey" :value="item.itemTitle">
          {{ item.itemTitle }}
        </option>
      </select>
      <template v-else>
        <div class="sk-selected-text" :class="{ 'sk-mobile-hide': iconOnlyForMobile }">
          <Channelimg v-if="showChannelImage && selectedValue" :channel="selectedValue" />{{ selectedValue }}
        </div>
        <label class="sk-floating-label" v-if="hasFloatingLabel">{{ lableText ? lableText : placeHolderText }}
          <span class="sk-required" v-if="isMandatory">*</span></label>
      </template>
      <SkIcon v-if="!hideDefaultIcon" :iconType="useSvg ? '' : 'expand_more'" :svgIcon="useSvg ? 'expand_more' : ''">
      </SkIcon>
    </div>

    <div class="sk-helper-line">
      <span class="sk-error-text" :class="{ 'sk-show': errorText && hasError }">{{ errorText }}</span>
      <span class="sk-helper-text" :class="{ 'sk-show': helperText && !hasError }">{{ helperText }}</span>
    </div>
    <div class="sk-overflow-wrapper" :class="{ 'sk-overflow-bottom': isListBottomSheet }">
      <div class="sk-overflow-list" :class="{ 'sk-show': showOptions }">
        <div v-if="!isNativeSelect && isListBottomSheet" class="sk-flex-row">
          <div class="sk-list-label">
            {{ placeHolderText }}
          </div>
          <SkButton v-if="isListBottomSheet" noShadow icon="close" small @click="showOptions = false" />
        </div>
        <ul v-if="!isNativeSelect && !hasMultiSelectOption">
          <li v-for="item in listItems" :key="item.itemKey"
            :class="{ 'sk-selected': item.itemKey === selectedItem, 'sk-disabled': item.disabled }"
            @click="selectOptionClick($event, item)">
            <Channelimg v-if="showChannelImage" :channel="item.itemKey" />{{
              item.itemTitle
            }}
            <SkIcon success icon-type="check" v-if="item.isSelected && isListBottomSheet" />
          </li>
        </ul>
        <ul v-if="!isNativeSelect && hasMultiSelectOption">
          <li v-for="item in listItems" :key="item.itemKey" @click="$event.stopPropagation()">
            <SkCheckbox :is-checkbox="true" :label-name="item.itemTitle" :chkid="item.itemKey"
              :isChecked="item.isSelected" @click="$event.preventDefault(), checkBoxClicked(item)"
              :disabled="item.disabled"></SkCheckbox>
          </li>
        </ul>
        <div v-if="hasMultiSelectOption" class="sk-list-footer">
          <div class="sk-button-group">
            <SkButton outline small @click="onResetClick()" :button-text="`Reset`" />
            <SkButton primary small :disabled="!ReactiveData.selectedItems.length" :button-text="`Submit`"
              @click="submitSelected()" />
          </div>
        </div>
      </div>
      <div v-if="isListBottomSheet" class="sk-backdrop"></div>
    </div>
  </div>
  <span v-if="listItems && listItems.filter(x => x.isSelected).length && isListBottomSheet" class="sk-badge sk-web-hide"></span>
</template>
